﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace
HOB_CM_test_rewrite.agents
{
    public abstract class
    AgentBase<A>
    where A:AgentBase<A>
    {

        public string
        name()
        {
            return mName;
        }

        protected Agent<A>
        owner()
        {
            if(mOwner.TryGetTarget(out var result))
            {
                return result;
            }

            return null;
        }

        private readonly string mName;
        private readonly WeakReference<Agent<A>> mOwner;
    }
}
