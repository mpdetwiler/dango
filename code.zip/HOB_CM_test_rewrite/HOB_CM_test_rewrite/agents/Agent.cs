﻿using System;
using System.Threading;

namespace
HOB_CM_test_rewrite.agents
{
    public abstract class
    Agent<A>
    where A:AgentBase<A>
    {

    }

    internal sealed class
    Message<A>
    where A:AgentBase<A>
    {
        public
        Message(in Action<A> func)
        {
            mFunc = func;
            next = null;
        }

        public Message<A>
        appendTo(in Message<A> tail)
        {
            return (tail.next = this);
        }

        public void
        apply(A agent)
        {
            mFunc.Invoke(agent);
        }

        public Message<A> next{ get; private set; }
        private readonly Action<A> mFunc;
    }

    internal sealed class
    AgentThread<A>
    where A:AgentBase<A>
    {

        private readonly MessageManager<A> mManager;
        private readonly Thread mThread;
    }

    internal sealed class
    MessageManager<A>
    where A:AgentBase<A>
    {
        public
        MessageManager()
        {
            mMonitor = new Object();
            mAlive = true;
            mWaiting = false;
            mHead = null;
            mTail = null;
        }

        public void
        kill()
        {
            lock(mMonitor)
            {
                if(mAlive)
                {
                    mAlive = false;

                    if(mWaiting)
                    {
                        Monitor.Pulse(mMonitor);
                    }
                }
            }
        }

        public bool
        processMessages
        (in A agent)
        {
            bool alive;
            Message<A> current;

            lock(mMonitor)
            {
                alive = mAlive;

                current = mHead;

                if(current == null)
                {
                    return alive;
                }

                mHead = mTail = null;
            }

            do
            {
                try
                {
                    current.apply(agent);
                }
                catch(AgentMessageException except)
                {
                    Console.WriteLine("Agent \"" + agent.name() + "\": Failed to send message:\n" + except.Message);
                }
                catch(Exception except)
                {
                    Console.WriteLine("Agent \"" + agent.name() + "\": Execption thrown during message processing:\n" + except.Message);

                    return false;
                }

                current = current.next;
            }
            while(current != null);

            return alive;
        }

        public void
        waitMessages()
        {
            lock(mMonitor)
            {
                while(mAlive && mHead == null)
                {
                    mWaiting = true;

                    Monitor.Wait(mMonitor);

                    mWaiting = false;
                }
            }
        }

        public void
        timedWaitMessages
        (in long deadline)
        {
            lock(mMonitor)
            {
                while(mAlive && mHead == null)
                {
                    var current = utility.Monotonic.currentTick();

                    if(current >= deadline)
                    {
                        break;
                    }

                    var timeout = (int)Math.Min((long)int.MaxValue, deadline - current);

                    mWaiting = true;

                    Monitor.Wait(mMonitor, timeout);

                    mWaiting = false;
                }
            }
        }

        public bool
        tryNewMessage
        (in Action<A> func)
        {
            var m = new Message<A>(func);

            lock(mMonitor)
            {
                if(!mAlive)
                {
                    return false;
                }

                if(mHead == null)
                {
                    mHead = mTail = m;
                }
                else
                {
                    mTail = m.appendTo(mTail);
                }

                if(mWaiting)
                {
                    Monitor.Pulse(mMonitor);
                }
            }

            return true;
        }

        public void
        newMessage
        (in Action<A> func, in string agentName)
        {
            if(!tryNewMessage(func))
            {
                throw new AgentMessageException(agentName);
            }
        }

        private readonly Object mMonitor;
        private bool mAlive;
        private bool mWaiting;
        private Message<A> mHead;
        private Message<A> mTail;
    }


}
