﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Windows.Forms;

namespace
HOB_CM_test_rewrite
{
    using static utility.Conversion;
    using static utility.Monotonic;

    static class
    Program
    {
        [STAThread]
        private static void
        Main()
        {
            Console.WriteLine(byteToStringHex(255));

            Thread.Sleep(1000);

            Console.WriteLine(currentTick());

            Thread.Sleep(1000);

            Console.WriteLine(currentTick());

            //Application.EnableVisualStyles();
            //Application.SetCompatibleTextRenderingDefault(false);
            //Application.Run(new Form1());
        }
    }
}
