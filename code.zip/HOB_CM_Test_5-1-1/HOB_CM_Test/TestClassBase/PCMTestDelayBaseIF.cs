﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HOB_CM_Test
{
    class PCMTestDelayBaseIF
    {
        public string m_ProgramID;

        public virtual int MeasPSVoltDelay() { return 1200; }
        public virtual int MeasOutputVDelay() { return 200; }
        public virtual int OverVoltageProtectionDelay() { return 1200; }
        public virtual int OverVoltageReleaseDelay() { return 1500; }
        public virtual int UnderVoltageProtectionDelay() { return 1000; }
        public virtual int UnderVoltageReleaseDelay() { return 1; }
        public virtual int UnderVoltageResetDelay() { return 2500; }
        public virtual int HighCurrLoadDelay() { return 500; }
        public virtual int OCDDelay() { return 700; }

        public string GetProgramID()
        {
            return m_ProgramID;
        }
    }
}
