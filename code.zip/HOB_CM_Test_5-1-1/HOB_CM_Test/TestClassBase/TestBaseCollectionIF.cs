﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace HOB_CM_Test
{
    class TestBaseCollectionIF : Conversion
    {
        ConfigData m_configData = new ConfigData();

        public BaseTestDb m_BaseTestdb = new BaseTestDb();
        public DataGridView m_dGV = null;

        public List<TestBase> m_TestObjColl = new List<TestBase>();
        public List<TestBase> m_CalTestObjColl = new List<TestBase>();

        public virtual void SetTextResultOutput(ref TextBox[] ar_txt) { }
        public virtual void RunPostTest() { }

        public virtual int IsMcDaqNeeded() { return 1; }
        public virtual int IsInfiPeriphAdaptorNeeded() { return 0; }
        public virtual int IsDMMNeeded() { return 0; }
        public virtual int IsPSNeeded() { return 1; }
        public virtual int IsDCLoadNeeded() { return 1; }
        public virtual int IsTestFileNeeded() { return 0; }
        public virtual void GetDataGridView() { }
        public virtual void PostTestDGVUpdate() { }
        public virtual void ConvertFromFileToDB(string filename) { }

        public TestBaseCollectionIF()
        {
            GetDataGridView();
            m_configData.LoadConfigFile();
        }

        public virtual string GetProgramID()
        {
            return "";
        }

        public virtual void SetDataBase()
        {
            foreach (TestBase tst in m_TestObjColl)
            {
                tst.SetTestDb(ref m_BaseTestdb);
            }

            foreach (TestBase tst in m_CalTestObjColl)
            {
                tst.SetTestDb(ref m_BaseTestdb);
            }
        }

        public void SetDataGridColumnCnt()
        {
            int cnt = m_dGV.ColumnCount;
            foreach (TestBase tst in m_TestObjColl)
            {
                tst.SetDataGridColumnCnt(cnt);
            }
        }

        public int GetDataGridColumnCnt()
        {
            return m_dGV.ColumnCount;
        }

        //0 = at least one failed.
        //1 = all passed.
        public virtual int AreAllTestPass()
        {
            int passOrfail = 1;
            foreach (TestBase tst in m_TestObjColl)
            {
                passOrfail &= tst.PassOrFail();
            }
            m_BaseTestdb.SetPassOrFail(passOrfail);
            return passOrfail;
        }

        public void PrintTestResultsFromFile(string job_number)
        {
            string file_name = "";

            OpenFileDialog OFD = new OpenFileDialog();
            OFD.InitialDirectory = m_configData.datalog_directory;
            if (OFD.ShowDialog() == DialogResult.OK)
            {
                file_name = OFD.FileName;
            }
            if (file_name == "")
            {
                MessageBox.Show("A file was not selected.");
                return;
            }

            ConvertFromFileToDB(file_name);

            PrintTestResults(job_number);

        }

        public void PrintTestResults(string job_number)
        {
            if (m_dGV == null)
                return;

            TextBox name = new TextBox();
            TextBox date = new TextBox();
            string m_footer;
            FormPrintLog fPrintLog = new FormPrintLog();
            fPrintLog.SetNameDateRef(ref name, ref date);
            fPrintLog.ShowDialog();
            m_footer = "Operator Signed as --> " + name.Text + " <--      Date " + DateTime.Now.ToString("yyyy/MM/dd/HH:mm:ss");

            DGVPrinter dGVPrinter = new DGVPrinter();
            dGVPrinter.Title = "Test Data Results for " + GetProgramID() + " JN " + job_number;
            dGVPrinter.SubTitle = DateTime.Now.ToString("yyyy/MM/dd/HH:mm:ss");
            dGVPrinter.SubTitleFormatFlags = StringFormatFlags.LineLimit | StringFormatFlags.NoClip;
            dGVPrinter.PageNumbers = true;
            dGVPrinter.PageNumberInHeader = false;
            dGVPrinter.PorportionalColumns = true;
            dGVPrinter.HeaderCellAlignment = StringAlignment.Near;
            dGVPrinter.Footer = m_footer;
            dGVPrinter.FooterSpacing = 15;

            PopulateDatGrid();
            dGVPrinter.PrintDataGridView(m_dGV);
        }

        public void PopulateDatGrid()
        {
            m_BaseTestdb.PopulateDatGrid(ref m_dGV);
        }

    }
}
