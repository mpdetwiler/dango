﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace HOB_CM_Test
{
    class ARTestReStruct
    {
        public string[] m_arTestResult = new string[10];
    }
    class BaseTestDb : Conversion
    {
        public double DIODE_DROP = 0.40;
        public double IR_DROP = .20;
        public double MIN_LION_VOLT = 3.0;

        public double[] mar_dgeneric = new double[10];
        int m_ResultIdx;
        public string[] mar_stResult = new string[10];

        public List<ARTestReStruct> m_TestResultList = new List<ARTestReStruct>();

        int m_PassOrFail;

        public BaseTestDb()
        {
            for (int idx = 0; idx < 10; idx++)
            {
                mar_dgeneric[idx] = 0;
            }
            m_ResultIdx = 0;
        }

        public void AddToResutString(string st, int index)
        {
            if (m_ResultIdx >= 10)
            {
                MessageBox.Show("BaseTestDb::AddToResutString: Index out of range.");
                return;
            }
            mar_stResult[index] = st;
            m_ResultIdx++;
        }

        public void ClearResultString()
        {
            for (int idx = 0; idx < 10; idx++)
            {
                mar_stResult[idx] = "";
            }
        }

        public void AddPassOrFailToString(int index)
        {
            if (m_PassOrFail == 1)
            {
                mar_stResult[index] = "P";
            }
            else
                mar_stResult[index] = "F";
        }

        public void ClearTestResultListDb()
        {
            m_TestResultList.Clear();
        }

        public void AddToTestResultList(int size)
        {

            ARTestReStruct aRTest = new ARTestReStruct();
            for (int idx = 0; idx < size; idx++)
            {
                aRTest.m_arTestResult[idx] = mar_stResult[idx];
            }
            m_TestResultList.Add(aRTest);
            m_ResultIdx = 0;
            ClearResultString();

        }

        public void SetPassOrFail(int val)
        {
            m_PassOrFail = val;
        }

        public int GetPassOrFail()
        {
            return m_PassOrFail;
        }

        public void PopulateDatGrid(ref DataGridView dgv)
        {
            int column_cnt = dgv.ColumnCount;
            int row_index = 0;
            DataGridViewRow row;

            //First clear the existing datagridview
            dgv.Rows.Clear();
            dgv.Refresh();

            foreach (ARTestReStruct tr in m_TestResultList)
            {
                row = (DataGridViewRow)dgv.Rows[row_index].Clone();
                for (int idx = 0; idx < column_cnt; idx++)
                {
                    row.Cells[idx].Value = tr.m_arTestResult[idx];
                    if (idx == column_cnt - 1)
                    {
                        if (tr.m_arTestResult[idx] == "F")
                        {
                            row.Cells[idx].Style.ForeColor = Color.Red;
                        }
                    }
                }
                dgv.Rows.Add(row);
                row_index++;
            }

            // ClearTestResultListDb();
        }
    }
}
