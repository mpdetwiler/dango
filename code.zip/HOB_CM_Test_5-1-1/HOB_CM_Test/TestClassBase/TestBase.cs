﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace HOB_CM_Test
{
    class TestBase
    {
        public ConfigData m_Config = new ConfigData();
        public BaseTestDb m_BaseTestdb = new BaseTestDb();

        public DCLoadIF m_DCLoadIF;
        public PSBaseIF m_PwrSupDev;
        public McDaqIF m_MccDaqIF;
        public DmmBaseIF m_DmmIF;
        public CANBusIF m_CANBusIF;
        public PackTestDelayBaseIF m_PTestDelayBaseIF;
        public PCMTestDelayBaseIF m_PCMTestDelayBaseIF;
        public TestDataLog m_Datalog;

        public TextBox m_txtOutput1, m_txtOutput2;
        public CheckBox[] mar_chkbox;
        public TextBox m_txtProgressInfo;
        public TextBox[] m_userTxtInfo;

        public int m_pass_fail; //0 fail; 1 pass
        public string m_ProgramID;

        public int m_column_cnt;
        public double m_curr_temp;
//        private TextBox[] m_txtUserInfo;

        //        public int m_dgv_idx;

        public TestBase()
        {
            m_pass_fail = 0;
            m_ProgramID = "";
            m_Config.LoadConfigFile();
        }

        public void SetDataGridColumnCnt(int val)
        {
            m_column_cnt = val;
        }

        public int GetDataGridColumnCnt()
        {
            return m_column_cnt;
        }

        public void SetPowerSupply(PSBaseIF PSupply)
        {
            m_PwrSupDev = PSupply;
        }

        public void SetDCLoad(DCLoadIF dcIF)
        {
            m_DCLoadIF = dcIF;
        }

        public void SetDMM(ref KeySi34461A dmm)
        {
            //m_DmmIF = dmm;
        }

        public void SetMccDagModule(McDaqIF mcc)
        {
            m_MccDaqIF = mcc;
        }

        public void SetDmmIF(DmmBaseIF dmm)
        {
            m_DmmIF = dmm;
        }

        public void SetCANBusIF(CANBusIF canB)
        {
            m_CANBusIF = canB;
        }

        public void SetDatalogRef(ref TestDataLog dl)
        {
            m_Datalog = dl;
        }

        public void SetProgramID(string id)
        {
            m_ProgramID = id;
        }

        public virtual string GetProgramID()
        {
            return m_ProgramID;
        }

        public virtual void SetTestDb(ref BaseTestDb db)
        {
            m_BaseTestdb = db;
        }

        public void LoadLimitsFile(string filename)
        {
            try
            {
                ReadLimitsFile(filename);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error reading file. " + ex.Message);
            }
        }

        //public void SetLimitListBox(ref ListBox lb)
        public void SettxtProgressInfo(ref TextBox txtbox)
        {
            m_txtProgressInfo = txtbox;
        }

//        public void SettxtUserInfo(ref TextBox[] usrInfo)
//        {
//            m_txtUserInfo = usrInfo;
//        }

        public void SetResultTextBox(ref TextBox tb1, ref TextBox tb2)
        {
            m_txtOutput1 = tb1;
            m_txtOutput2 = tb2;
        }


        public void ClearBeforeRunDisplay()
        {
            if (m_txtOutput1 == null || m_txtOutput2 == null)
                return;

            if (ClearTextBeforeRun() == 1)
            {
                m_txtOutput1.Text = "";
                m_txtOutput2.Text = "";
                m_txtOutput1.BackColor = Color.White;
                m_txtOutput2.BackColor = Color.White;
                Application.DoEvents();
            }
        }

        public void ClearPostRunDisplay()
        {
            if (m_txtOutput1 == null || m_txtOutput2 == null)
                return;

            if (ClearTextAfterRun() == 1)
            {
                m_txtOutput1.Text = "";
                m_txtOutput2.Text = "";
                m_txtOutput1.BackColor = Color.White;
                m_txtOutput2.BackColor = Color.White;
                Application.DoEvents();
            }
        }

        public void SetCheckBox(ref CheckBox[] ar_ck)
        {
            mar_chkbox = ar_ck;
        }

        public void AddtoDataLog(string str)
        {
            m_Datalog.AddtoDataLog(str);
        }

        public void SetPackTestDelayIF(string programID)
        {
            //For PackDelay 
/*
            if (programID == "MTI_102089-02")
                m_PTestDelayBaseIF = new MTI_102089_02();
            else if (programID == "MTI_108010-02")
                m_PTestDelayBaseIF = new MTI_108010_02();
            else if (programID == "MTI_105884-02")
                m_PTestDelayBaseIF = new MTI_105884_02();
            else if (programID == "MTI_102589-03")
                m_PTestDelayBaseIF = new MTI_102589_03();
            else if (programID == "MTI_104807-03")
                m_PTestDelayBaseIF = new MTI_104807_03();
            else
                m_PTestDelayBaseIF = new PackTestDelayBaseIF();
*/
            //For Board Delay
//            if (programID == "MTI_999999-14")
//                m_PCMTestDelayBaseIF = new MTI_999999_14();
//            else
//                m_PCMTestDelayBaseIF = new PCMTestDelayBaseIF();
        }

        public virtual int ClearTextBeforeRun() { return 1; }
        public virtual int ClearTextAfterRun() { return 0; }

        public int PassOrFail() { return m_pass_fail; }    //0 fail; 1 pass;
        public void SetPassFail(int val) { m_pass_fail = val; }

        public virtual void DisplayLimitToLstBox() { }
        public virtual void ReadLimitsFile(string filename) { }
        public virtual void ExecuteTest() { }

    }
}
