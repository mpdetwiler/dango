﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HOB_CM_Test
{
    class PackTestDelayBaseIF
    {
        public string m_ProgramID;

        public virtual int WakeUpDelay() { return 1600; }
        public virtual int WakeUpDelayEx() { return 1; }
        public virtual int TestOCVDelay() { return 500; }
        public virtual int ChargeAcceptDelay() { return 1; }
        public virtual int TestDischargeDelay() { return 500; }
        public virtual int TestLightLoadDelay() { return 500; }
        public virtual int TestOCDDelay() { return 1000; }
        public virtual int TestPostTestDelay() { return 2000; }
        public virtual int TestPostTestDelayEx() { return 10; }

        public string GetProgramID()
        {
            return m_ProgramID;
        }
    }
}
