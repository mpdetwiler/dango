﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HOB_CM_Test
{
    public partial class FormPrintLog : Form
    {
        TextBox m_txtName, m_txtDate;
        public FormPrintLog()
        {
            InitializeComponent();
        }

        public void SetNameDateRef(ref TextBox name, ref TextBox date)
        {
            m_txtName = name;
            m_txtDate = date;
        }

        private void btFormPrintLogPr_Click(object sender, EventArgs e)
        {
            if ((txtPrintLogName.Text == ""))
            {
                MessageBox.Show("Please enter your name and/or date.");
                return;
            }
            else
            {
                m_txtName.Text = txtPrintLogName.Text;
                m_txtDate.Text = DateTime.Now.ToString("dd'/'MM'/'yyyy HH:mm:ss");
                this.Close();
            }
        }

        private void FormPrintLog_Load(object sender, EventArgs e)
        {

        }
    }
}
