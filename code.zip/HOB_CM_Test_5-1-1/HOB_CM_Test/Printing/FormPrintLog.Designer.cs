﻿namespace HOB_CM_Test
{
    partial class FormPrintLog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtPrintLogName = new System.Windows.Forms.TextBox();
            this.btFormPrintLogPr = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(62, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(178, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Please Enter Your Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(114, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Name";
            // 
            // txtPrintLogName
            // 
            this.txtPrintLogName.Location = new System.Drawing.Point(65, 72);
            this.txtPrintLogName.Name = "txtPrintLogName";
            this.txtPrintLogName.Size = new System.Drawing.Size(137, 20);
            this.txtPrintLogName.TabIndex = 2;
            // 
            // btFormPrintLogPr
            // 
            this.btFormPrintLogPr.Location = new System.Drawing.Point(92, 98);
            this.btFormPrintLogPr.Name = "btFormPrintLogPr";
            this.btFormPrintLogPr.Size = new System.Drawing.Size(81, 26);
            this.btFormPrintLogPr.TabIndex = 3;
            this.btFormPrintLogPr.Text = "Print";
            this.btFormPrintLogPr.UseVisualStyleBackColor = true;
            // 
            // FormPrintLog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(281, 141);
            this.Controls.Add(this.btFormPrintLogPr);
            this.Controls.Add(this.txtPrintLogName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "FormPrintLog";
            this.Text = "Enter Name & Date";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtPrintLogName;
        private System.Windows.Forms.Button btFormPrintLogPr;
    }
}