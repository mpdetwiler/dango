﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Reflection;
using System.Runtime.CompilerServices;

namespace HOB_CM_Test
{
    public partial class TestMain : Form
    {
        bool debug_enable;

        TestFlowCtrl m_LoadProgramFLCtrl;
        TestFlowCtrl m_PCBTestFLCtrl;
        TestFlowCtrl m_PackTestVerificationCtrl;

        LoadProgramColl LoadProgCollection;
        PCBTestColl LoadPCBTestCollection;
        PackTestColl LoadPackTestCollection;
        EquipmentControl m_EqControl = new EquipmentControl();
        static McDaqUSB1208 m_mcDaqControl = new McDaqUSB1208();
       

        private TextBox[] gui_txtUserInfo;
        private Button[] gui_btnUserInfo;
        private TextBox[] gui_txtProgressInfo;

        public static TestMain Self;

        public int test_counter = 0;

        public string last_test_method;
        public bool last_is_latch_on = true;
        public static bool is_latch_on;

        public TestMain()
        {
            Self = this;
            InitializeComponent();
            debug_enable = false;

            LoadPackTestCollection = new PackTestColl();

            m_PackTestVerificationCtrl = new TestFlowCtrl();

            gui_txtUserInfo = new TextBox[] { txtJobNumber, txtPartNumber, txtOperator, txtSerialNumber, txtTemperature };
            gui_btnUserInfo = new Button[] { btnTest, btnCancel };
            gui_txtProgressInfo = new TextBox[] { txtPass, txtFail, txtYield };
            

            m_PackTestVerificationCtrl.SetTestBaseCollIF(LoadPackTestCollection);
            m_PackTestVerificationCtrl.SetUserTestInfo(ref gui_txtUserInfo, ref gui_btnUserInfo);
            m_PackTestVerificationCtrl.SetProgressInfo(ref gui_txtProgressInfo, ref txtProgressInfo, ref btnStatus);
            //m_PackTestVerificationCtrl.SetDebug(ref cmbSelectTest, ref btnDebug);
            m_PackTestVerificationCtrl.SetParameters();

            //cmbSelectTest.Items.Add("Preliminary");
            try
            {
                presence_pin(0);
            }
            catch
            {
                MessageBox.Show("Can't Find MccDaq Board.");
                //System.Threading.Thread.Sleep(5000);
                Close();
            }
            
            load_relay(1);
            supply_relay(0);

            cmbSelectTest.SelectedItem = "Final";

        }

        public static string GetAssemblyTitleAndVersion()
        {
            AssemblyName assemblyName = Assembly.GetEntryAssembly().GetName();
            Version assemblyVer = Assembly.GetEntryAssembly().GetName().Version;
            string buildDate = Properties.Resources.BuildDate;

            return assemblyName.Version.ToString() + " " + buildDate;
        }

        private void TestMain_Load(object sender, EventArgs e)
        {
            try
            {
                Text = Text + " " + GetAssemblyTitleAndVersion();
            }
            catch(Exception x)
            {
                Console.WriteLine("Error: " + x.Message);
                MessageBox.Show("Error: " + x.Message, "Confirmation", MessageBoxButtons.OK);
            }

            txtTemperature.Text = "24";
        }

        private void btnTroubleshoot_Click(object sender, EventArgs e)
        {
            if (debug_enable == false)
            {
                debug_enable = true;
                cmbSelectTest.Enabled = true;
                btnDebug.Text = "Debug Enabled";
            }
            else
            {
                debug_enable = false;
                cmbSelectTest.Enabled = false;
                btnDebug.Text = "Debug Disabled";
            }
        }

        private void btnTest_Click(object sender, EventArgs e)
        {
            System.Console.WriteLine(cmbSelectTest.SelectedItem.ToString());

 
            m_EqControl.SetTestFlowControl(ref m_PackTestVerificationCtrl);
            m_EqControl.SetTFEquipment();

            m_PackTestVerificationCtrl.RunTest();

        }

       static void ShowMessage(string message, [CallerLineNumber] int lineNumber = 0, [CallerMemberName] string caller = null)
        {
            MessageBox.Show(message + " at line " + lineNumber + " (" + caller + ")");
        }

        public void UpdateTxtProgressInfo(string msg, int status)
        {
            int stringlen = 70;
            int lengthlen = msg.Length;
            if (status == 0)
            {
                msg = msg.PadRight(stringlen, '.') + "F";
            }
            else if (status == 1)
                msg = msg.PadRight(stringlen, '.') + "P";
            else
                msg = msg + "                       ";
            txtProgressInfo.Text += msg + Environment.NewLine;
            txtProgressInfo.Refresh();
            txtProgressInfo.SelectionStart = txtProgressInfo.TextLength;
            txtProgressInfo.ScrollToCaret();
        }

        private void tmrOne_Tick(object sender, EventArgs e)
        {
            try
            {
                UpdateLatchSw();

                if (is_latch_on)
                {
                    btnLatchSw.BackColor = Color.LightGreen;
                }
                else
                {
                    btnLatchSw.BackColor = Color.Salmon;
                }

                /*if (cmbSelectTest.Text == "Preliminary")
                {
                    btnTest.Enabled = true;
                }
                else if (is_latch_on && cmbSelectTest.Text == "Final")
                {
                    btnTest.Enabled = true;
                }
                else
                {
                    btnTest.Enabled = false;
                }*/

                if (cmbSelectTest.Text == "Preliminary" && last_test_method != "Preliminary")
                {
                    btnTest.Enabled = true;
                }
                else if (cmbSelectTest.Text == "Final" && is_latch_on && !last_is_latch_on)
                {
                    btnTest.Enabled = true;
                }
                else if (cmbSelectTest.Text == "Final" && !is_latch_on && last_is_latch_on)
                {
                    btnTest.Enabled = false;
                }
                else if (cmbSelectTest.Text == "Final" && !is_latch_on && last_test_method == "Preliminary")
                {
                    btnTest.Enabled = false;
                }
            }
            catch { }

            last_test_method = cmbSelectTest.Text;
            last_is_latch_on = is_latch_on;
        }

        private void btnLatchSw_Click(object sender, EventArgs e)
        {
            
        }

        static public void UpdateLatchSw()
        {
            if ((m_mcDaqControl.ReadPortBData() & 10000000) == 0)
            {
                is_latch_on = true;
            }
            else
            {
                is_latch_on = false;
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtJobNumber_TextChanged(object sender, EventArgs e)
        {

        }

        public void supply_relay(int state)
        {
            m_mcDaqControl.SetPortAChan(1,state);
        }

        public void load_relay(int state)
        {
            m_mcDaqControl.SetPortAChan(2, state);
        }

        public void presence_pin(int state)
        {
            m_mcDaqControl.SetPortAChan(4, state);
        }


        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void cmbSelectTest_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }

        public string get_testmode()
        {
            return cmbSelectTest.SelectedItem.ToString();
        }

        private void btnStatus_Click(object sender, EventArgs e)
        {

        }

        public string get_partnum_prefix()
        {
            string return_string = txtPartNumber.Text.Split('-')[0];
            return return_string;
        }

        public string get_partnum_number()
        {
            string return_string = txtPartNumber.Text.Split('-')[1];
            return return_string;
        }

        public string get_partnum_revision()
        {
            string return_string = txtPartNumber.Text.Split('-').Last<string>();
            return return_string;
        }

        public string get_partnum_variant()
        {
            string[] partnum_array = txtPartNumber.Text.Split('-');
            if (partnum_array.Length == 4 && Int32.TryParse(partnum_array[2], out int num) == true)
            {
                return partnum_array[2];
            }
            else
            {
                return "0";
            }
        }

        public string get_serial_number()
        {
            string return_string = txtSerialNumber.Text;
            return return_string;
        }
    }
}
