﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HOB_CM_Test
{
    public class Conversion
    {
        public string ByteToStringHex(byte val)
        {
            return val.ToString("X2");
        }

        public string ByteToString(byte val)
        {
            return val.ToString();
        }

        public int HexStringToInt(string str)
        {
            return Int32.Parse(str, System.Globalization.NumberStyles.HexNumber);
        }

        public double StringToDouble(string str)
        {
            return double.Parse(str, System.Globalization.CultureInfo.InvariantCulture);
        }

        //        public int HexStringToInt(string str)
        //        {
        //            return Convert.ToInt32(str, 16);
        //        }

        public bool IsNumeric(object Expression)
        {
            int retNum;
            bool isNum = Int32.TryParse(Convert.ToString(Expression), System.Globalization.NumberStyles.HexNumber, System.Globalization.NumberFormatInfo.InvariantInfo, out retNum);
            return isNum;
        }

        public int DoesArStringContain(ref string[] ar_st, string st_check)
        {
            int cnt = ar_st.Length;
            for (int idx = 0; idx < cnt; idx++)
            {
                if (ar_st[idx] == st_check)
                    return 1;
            }
            return 0;
        }
    }
}
