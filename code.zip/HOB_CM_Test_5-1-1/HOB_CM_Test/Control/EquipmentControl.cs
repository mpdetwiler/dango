﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HOB_CM_Test
{
    class EquipmentControl
    {
        BK8500IF m_DCLoadIFIF;
        BK9122APSIF m_BK9122AP;
        KeySiE36103AIF m_KeySiE36103A;
        KeySiE3633AIF m_KeySiE3633A;
     
   
      
        KeySi34461AIF m_KeySi34461AIF;
       
        PSBaseIF m_PSBaseIF;
        DCLoadIF m_DCLoadIF;
        DmmBaseIF m_DmmBaseIF;
        CANBusIF m_CANBusIF;
        BK9201PSIF m_BK9201PSIF;

       
        McDaqUSB231 m_McDaqUSB231;
        McDaq1408FS m_McDaq1408FS;
    
        McDaqUSB1208 m_McDaqUSB1208;
        McDaqIF m_McDaqIF;

        int m_DCLoad_created, m_PS_created, m_DMM_created, m_McDaq_created;

        TestFlowCtrl m_TFCtrl;
        TestBaseCollectionIF m_TBColl;

        ConfigData m_ConfigData = new ConfigData();

        // ~EquipmentControl()
        //   {
        //         m_McDaqIF.EnableLoadConnection(0);
        //       }

        public EquipmentControl()
        {
            m_DCLoad_created = 0;
            m_PS_created = 0;
            m_DMM_created = 0;
            m_McDaq_created = 0;
            m_ConfigData.LoadConfigFile();
        }

        public void SetTestFlowControl(ref TestFlowCtrl tf)
        {
            m_TFCtrl = tf;
            m_TBColl = m_TFCtrl.GetTestBaseCollIF();
        }

        public void AssignDCLoadEquipment()
        {
            if (m_TBColl.IsDCLoadNeeded() == 1)
            {
                if (m_DCLoad_created == 0)
                {
                    if (m_ConfigData.BK8500 == "1")
                    {
                        m_DCLoadIFIF = new BK8500IF();
                        m_DCLoad_created = 1;
                        m_DCLoadIF = m_DCLoadIFIF;
                    }
                   
                }
                m_TFCtrl.AssignDCLoad(m_DCLoadIF);
            }
        }

        public void AssignDMMEquipment()
        {
            if (m_TBColl.IsDMMNeeded() == 1)
            {
                if (m_DMM_created == 0)
                {
                   
                    if (m_ConfigData.KeySi34461ADmm == "1")
                    {
                        m_KeySi34461AIF = new KeySi34461AIF();
                        m_DmmBaseIF = m_KeySi34461AIF;
                        m_DMM_created = 1;
                    }
                }
                m_TFCtrl.AssignDMM(m_DmmBaseIF);
            }
        }

        public void AssignPSEquipment()
        {
            if (m_TBColl.IsPSNeeded() == 1)
            {
                if (m_PS_created == 0)
                {
                    if(m_ConfigData.BK9201 == "1")
                    {
                        m_BK9201PSIF = new BK9201PSIF();
                        m_PS_created = 1;
                        m_PSBaseIF = m_BK9201PSIF;
                    }
                    if (m_ConfigData.BK9122A == "1")
                    {
                        m_BK9122AP = new BK9122APSIF();
                        m_PS_created = 1;
                        m_PSBaseIF = m_BK9122AP;
                    }
                    if (m_ConfigData.KeySiE36103A == "1")
                    {
                        m_KeySiE36103A = new KeySiE36103AIF();
                        m_PS_created = 1;
                        m_PSBaseIF = m_KeySiE36103A;
                    }
                    if (m_ConfigData.KeySiE3633A == "1")
                    {
                        m_KeySiE3633A = new KeySiE3633AIF();
                        m_PS_created = 1;
                        m_PSBaseIF = m_KeySiE3633A;
                    }
                   
                   
                }
                m_TFCtrl.AssignPowerSupply(m_PSBaseIF);
            }
        }

        public void AssignMcDaqEquipment()
        {
            try
            {
                if (m_TBColl.IsMcDaqNeeded() == 1)
                {
                    if (m_McDaq_created == 0)
                    {
                       
                        if(m_ConfigData.McDaqUSB1208 == "1")
                        {
                            m_McDaqUSB1208 = new McDaqUSB1208();
                            m_McDaqIF = m_McDaqUSB1208;
                            m_McDaq_created = 1;
                        }
                        
                    }
                    m_TFCtrl.AssignMcDaq(m_McDaqIF);
                }
            }
            catch(Exception e)
            {
                MessageBox.Show("Error: " + e, "error", MessageBoxButtons.OK);
            }
        }

        public void AssignCANBusCom()
        {
            m_CANBusIF = new CANBusIF();
           
            m_TFCtrl.AssignCANBus(m_CANBusIF);
        }

        public void SetTFEquipment()
        {
            AssignMcDaqEquipment();
            AssignDCLoadEquipment();
            //AssignDMMEquipment();
            AssignPSEquipment();
            //SetMcDaqToPwrSp();
            //SetMcDaqToDCLoad();
            //AssignCANBusCom();
        }

        public void SetMcDaqToPwrSp()
        {
            if (m_TBColl.IsPSNeeded() == 1)
                m_PSBaseIF.SetMcDaqIF(m_McDaqIF);
        }

        public void SetMcDaqToDCLoad()
        {
            if (m_TBColl.IsDCLoadNeeded() == 1)
                m_DCLoadIF.SetMcDaqIF(m_McDaqIF);
        }

    }
}
