﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace HOB_CM_Test
{
    class ConfigData
    {
        //equipment variables
        public string BK_comport;
        public string BK_PS_comport;
        public string BK2831EDmm_comport;
        public string DMM_VISA_addr;
        public string PS_VISA_addr;
        public string Test_File_Dir;
        public string KEYSI_E36103A_VISA_addr;
        public string BK9122A;
        public string BK9201;
        public string KeySiE36103A;
        public string KeySiE3633A;
        public string RiGolDp1116A;
        public string IWHPS36V3A;
        public string KeithLey2303;
        public string BK8500;
        public string IWHEL300DCLoad;
        public string BK2831EDmm;
        public string KeySi34461ADmm;
        public string ZHB_FX0515;
        public string ZHB_FX0382;
        public string McDaqUSB231;
        public string McDaq1408FS;
        public string McDaqFX0571;
        public string McDaqUSB1208;
        public string PSBK_VISA_addr;


        public string test_code;

        public string datalog_directory;
        public string prelim_test_datalog_directory;
        public string can_datalog_directory;
        public string load_program_directory;
        public string test_limits_directory;

        public const string eqpmt_config_filename = "c:\\PCM_Test_Program\\Config\\equipment_config.xml";
        public string load_program = "c:\\PCM_Test_Program\\Config\\load_program.xml";
        public const string test_limits = "c:\\PCM_Test_Program\\Test_File\\test_limits.xml";

        public ConfigData()
        {
            datalog_directory = "c:\\PCM_Test_Program\\Datalog\\";
            prelim_test_datalog_directory = "c:\\PCM_Test_Program\\Preliminary_Test_Datalog\\";
            can_datalog_directory = "c:\\PCM_Test_Program\\CANDatalog\\";
            load_program_directory = "c:\\PCM_Test_Program\\Config\\";
            test_limits_directory = "c:\\PCM_Test_Program\\Test_File\\";
        }

        public void LoadConfigFile()
        {
            try
            {
                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.Load(eqpmt_config_filename);
                XmlNodeList nodeList = xmlDoc.DocumentElement.SelectNodes("/Table");
                try
                {
                    foreach (XmlNode node in nodeList)
                    {
                        BK_comport = node.SelectSingleNode("BK_COMPORT").InnerText; //use for electronic load
                        BK_PS_comport = node.SelectSingleNode("BK_PS_COMPORT").InnerText;
                        PSBK_VISA_addr = node.SelectSingleNode("PSBK_VISA_ADDR").InnerText;
                        BK2831EDmm_comport = node.SelectSingleNode("BK2831EDMM_COMPORT").InnerText;
                        DMM_VISA_addr = node.SelectSingleNode("DMM_VISA_ADDR").InnerText;
                        PS_VISA_addr = node.SelectSingleNode("PS_VISA_ADDR").InnerText;
                        KEYSI_E36103A_VISA_addr = node.SelectSingleNode("PS_VISA_ADDR").InnerText;
                        Test_File_Dir = node.SelectSingleNode("XML_DIR_PATH").InnerText;
                        BK9122A = node.SelectSingleNode("BK9122A_PS").InnerText;
                        BK9201 = node.SelectSingleNode("BK9201_PS").InnerText;
                        KeySiE36103A = node.SelectSingleNode("KEYSIE36103A_PS").InnerText;
                        KeySiE3633A = node.SelectSingleNode("KEYSIE3633A_PS").InnerText;
                        RiGolDp1116A = node.SelectSingleNode("RIGOLDP1116A_PS").InnerText;
                        IWHPS36V3A = node.SelectSingleNode("IWHPS36V3A_PS").InnerText;
                        KeithLey2303 = node.SelectSingleNode("Keithley2303PJ_PS").InnerText;
                        BK8500 = node.SelectSingleNode("BK8500_DCLOAD").InnerText;
                        IWHEL300DCLoad = node.SelectSingleNode("IWHEL300DC_DCLOAD").InnerText;
                        BK2831EDmm = node.SelectSingleNode("BK2831EDMM").InnerText;
                        KeySi34461ADmm = node.SelectSingleNode("KEYSI34461ADMM").InnerText;
                        ZHB_FX0515 = node.SelectSingleNode("ZHB_FX0515").InnerText;
                        ZHB_FX0382 = node.SelectSingleNode("ZHB_FX0382").InnerText;
                        McDaqUSB231 = node.SelectSingleNode("MCDAQUSB231").InnerText;
                        McDaq1408FS = node.SelectSingleNode("MCDAQ1408FS").InnerText;
                        McDaqFX0571 = node.SelectSingleNode("MCDAQFX0571").InnerText;
                        McDaqUSB1208 = node.SelectSingleNode("MCDAQUSB1208").InnerText;
                    }
                }
                catch(Exception e)
                {
                    MessageBox.Show("There might be an issue with the config file. One ore more key name missing.. " + e);
                }
            }
            catch(Exception e)
            {
                MessageBox.Show("There may be an issue with the config file format. " + e);
            }
        }

        public void LoadProgramFile(string programfile)
        {
            try
            {
                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.Load(programfile);
                XmlNodeList nodelist = xmlDoc.DocumentElement.SelectNodes("/Table");

                try
                {
                    foreach (XmlNode node in nodelist)
                    {
                        test_code = node.SelectSingleNode("TEST_PROGRAM_FILE").InnerText;
                    }
                }
                catch(Exception e)
                {
                    MessageBox.Show("There might be an issue with the program file. One ore more key name missing.. " + e);
                }

            }
            catch(Exception e)
            {
                MessageBox.Show("There may be an issue with the program file format.  " + e);
            }
        }
    }
}
