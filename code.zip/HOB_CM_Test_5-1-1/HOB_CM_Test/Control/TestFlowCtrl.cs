﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Drawing;

namespace HOB_CM_Test
{
    class TestFlowCtrl
    {
        TestDataLog m_Datalog = new TestDataLog();
        TestBaseCollectionIF m_TestBaseCollIF;
        ConfigData m_ConfigData = new ConfigData();
        TestClassTestCAN m_TestCAN = new TestClassTestCAN();

        TextBox[] mar_txtUser;
        ComboBox mar_debug;
        TextBox[] mar_equipment;
        Button mar_btnprogress;
        TextBox[] mar_txtprogress;
        Button[] mar_usrbtn;
//        TextBox mar_txtProgressInfo;

        int m_load_test_file;
        int m_limtloaded;
        int m_dmm_assign;
        int m_dcload_assign;
        int m_ps_assign;
        int m_mcdaq_assign;
        int m_canbus_assign;
        float m_TestCounterPass;
        float m_TestCounterFail;

        public TestFlowCtrl()
        {
            m_ConfigData.LoadConfigFile();
            m_load_test_file = 0;
            m_limtloaded = 0;
            m_dmm_assign = 0;
            m_dcload_assign = 0;
            m_ps_assign = 0;
            m_mcdaq_assign = 0;
            m_TestCounterPass = 0;
            m_TestCounterFail = 0;
            m_canbus_assign = 0;
        }

        public void SetTestBaseCollIF(TestBaseCollectionIF tbif)
        {
            m_TestBaseCollIF = tbif;
        }

        public TestBaseCollectionIF GetTestBaseCollIF()
        {
            return m_TestBaseCollIF;
        }

        public void SetParameters()
        {
            foreach (TestBase tst in m_TestBaseCollIF.m_TestObjColl)
            {
                tst.SetDatalogRef(ref m_Datalog);
            }
        }

        public void SetUserTestInfo(ref TextBox[] usrtxtbox, ref Button[] usrbtn)
        {
            mar_txtUser = usrtxtbox;
            mar_usrbtn = usrbtn;
//            foreach(TestBase tst in m_TestBaseCollIF.m_TestObjColl)
//            {
//                tst.SettxtUserInfo(ref usrtxtbox);
//            }
        }

        public void SetProgressInfo(ref TextBox[] progtxtbox, ref TextBox txtProgressInfo, ref Button progressbtn)
        {

            mar_txtprogress = progtxtbox;
            mar_btnprogress = progressbtn;
            //mar_txtProgressInfo = txtProgressInfo;
            foreach(TestBase tst in m_TestBaseCollIF.m_CalTestObjColl)
            {
                tst.SettxtProgressInfo(ref txtProgressInfo);
            }
        }

        public void SetDebug(ref ComboBox debugcmbbox, ref Button debugbtn)
        {
            mar_debug = debugcmbbox;

            foreach(TestBase tst in m_TestBaseCollIF.m_TestObjColl)
            {
                mar_debug.Items.Add(tst.ToString());
            }
        }

        public void AssignDCLoad(DCLoadIF dcIF)
        {
            if (m_dcload_assign == 1)
                return;

            string temp;
            temp = "";

            dcIF.GetCOMPortList(ref temp);
            TestMain.Self.UpdateTxtProgressInfo(temp, 2);
            //mar_equipment[2].Text = temp;

            foreach (TestBase tst in m_TestBaseCollIF.m_TestObjColl)
                tst.SetDCLoad(dcIF);
            m_dcload_assign = 1;
        }

        public void AssignDMM(DmmBaseIF dmmIF)
        {
            if (m_dmm_assign == 1)
                return;

            foreach (TestBase tst in m_TestBaseCollIF.m_TestObjColl)
                tst.SetDmmIF(dmmIF);

            //mar_equipment[0].Text = "";
            //mar_equipment[0].Text = dmmIF.GetInstrumentID();
            TestMain.Self.UpdateTxtProgressInfo(dmmIF.GetInstrumentID(), 2);

            m_dmm_assign = 1;
        }

        public void AssignMcDaq(McDaqIF mdif)
        {
            if (m_mcdaq_assign == 1)
                return;

            foreach (TestBase tst in m_TestBaseCollIF.m_TestObjColl)
                tst.SetMccDagModule(mdif);

            foreach (TestBase tst in m_TestBaseCollIF.m_CalTestObjColl)
                tst.SetMccDagModule(mdif);

            m_mcdaq_assign = 1;
        }

        public void AssignPowerSupply(PSBaseIF psIF)
        {
            if (m_ps_assign == 1)
                return;

            foreach (TestBase tst in m_TestBaseCollIF.m_TestObjColl)
                tst.SetPowerSupply(psIF);

            TestMain.Self.UpdateTxtProgressInfo(psIF.GetInstrumentID(), 2);

            m_ps_assign = 1;
        }

        public void AssignCANBus(CANBusIF canIF)
        {
            if (m_canbus_assign == 1)
                return;

            foreach (TestBase tst in m_TestBaseCollIF.m_TestObjColl)
                tst.SetCANBusIF(canIF);

            m_canbus_assign = 1;
        }

        private void SetDatalogParam()
        {
            m_Datalog.SetJobNumber(mar_txtUser[0].Text);
            m_Datalog.PartNumber(mar_txtUser[1].Text);
            m_Datalog.SetOperator(mar_txtUser[2].Text);
            m_Datalog.SerialNumber(mar_txtUser[3].Text);
        }

        private void SetTempRef()
        {
            m_TestCAN.SetTemperatureRef = (mar_txtUser[4].Text);
        }

        private string GetTestFileName()
        {
            /* OpenFileDialog OFD = new OpenFileDialog();

            OFD.InitialDirectory = m_ConfigData.Test_File_Dir;
            OFD.Filter = "txt files (*.xml)|*.xml";

            if (OFD.ShowDialog() == DialogResult.OK)
            {
                return OFD.FileName;
            }
            */

            TextBox txtMTI = new TextBox();
            MTIBrcodeRder BRder = new MTIBrcodeRder();
            BRder.SetMTIBarCode(ref txtMTI);
            BRder.ShowDialog();
            return txtMTI.Text;
        }

        public void Calibrate()
        {
            foreach (TestBase tst in m_TestBaseCollIF.m_CalTestObjColl)
                tst.ExecuteTest();
        }

        public void LoadLimitsOnly(int force)
        {
            if (force == 1)
            {
//                m_listBox.Items.Clear();

                foreach (TestBase tst in m_TestBaseCollIF.m_TestObjColl)
                    tst.DisplayLimitToLstBox();

                m_Datalog.SetProgramID(m_TestBaseCollIF.GetProgramID());
                mar_equipment[3].Text = m_TestBaseCollIF.GetProgramID();

                m_load_test_file = 1;
                m_limtloaded = 1;
            }

            else
            {
                if (m_limtloaded == 0)
                {
//                    m_listBox.Items.Clear();

                    foreach (TestBase tst in m_TestBaseCollIF.m_TestObjColl)
                        tst.DisplayLimitToLstBox();

                    m_Datalog.SetProgramID(m_TestBaseCollIF.GetProgramID());
                    mar_equipment[3].Text = m_TestBaseCollIF.GetProgramID();

                    m_load_test_file = 1;
                    m_limtloaded = 1;
                }
            }
        }

        public void LoadTestFile()
        {
            if (m_TestBaseCollIF.IsTestFileNeeded() == 1)
            {
                string filename;
//                m_listBox.Items.Clear();

                filename = GetTestFileName();
                if (filename == "")
                {
                    m_load_test_file = 0;
                    return;
                }
                filename = m_ConfigData.test_limits_directory + filename + ".xml";
                if ((File.Exists(filename)) == false)
                {
                    m_load_test_file = 0;
                    MessageBox.Show("Either the MTI number is invalid or the test file does not exist.  Please try again.");
                    return;
                }

                foreach (TestBase tst in m_TestBaseCollIF.m_TestObjColl)
                {
                    tst.LoadLimitsFile(filename);
                    tst.DisplayLimitToLstBox();
                }

                foreach (TestBase tst in m_TestBaseCollIF.m_TestObjColl)
                {
                    tst.SetPackTestDelayIF(m_TestBaseCollIF.m_TestObjColl[0].GetProgramID());
                }
            }

            m_Datalog.SetProgramID(m_TestBaseCollIF.GetProgramID());
            mar_equipment[3].Text = m_TestBaseCollIF.GetProgramID();

            m_load_test_file = 1;
        }

        public void PrintTestResults(int file_or_db = 0)
        {
            if (CheckPreTestRunCondition() == -1)
                return;

            if (file_or_db == 0)
                m_TestBaseCollIF.PrintTestResults(mar_txtUser[0].Text);
            else
                m_TestBaseCollIF.PrintTestResultsFromFile(mar_txtUser[0].Text);
        }

        private int CheckPreTestRunCondition()
        {
/*
            if (m_load_test_file == 0)
            {
                System.Media.SystemSounds.Exclamation.Play();
                MessageBox.Show("Please load the test file first.");
                return -1;
            }
*/
            if (mar_txtUser[0].Text == String.Empty)
            {
                System.Media.SystemSounds.Exclamation.Play();
                MessageBox.Show("Please enter a Job Number.");
                return -1;
            }

            int jobnumber;

            if (!int.TryParse(mar_txtUser[0].Text, out jobnumber))
            {
                System.Media.SystemSounds.Exclamation.Play();
                MessageBox.Show("The job number cannot contain any letters.");
                return -1;
            }

            if (jobnumber < 30000)          //job number must start with a 3 and must have 5 digits
            {
                System.Media.SystemSounds.Exclamation.Play();
                MessageBox.Show("The job number entered must start with a \"3\" and must have 5 digits.");
                return -1;
            }

            if (mar_txtUser[1].Text == String.Empty)
            {
                System.Media.SystemSounds.Exclamation.Play();
                MessageBox.Show("Please enter Part Number.");
                return -1;
            }

            if (mar_txtUser[2].Text == String.Empty)
            {
                System.Media.SystemSounds.Exclamation.Play();
                MessageBox.Show("Please enter an operator name ...");
                return -1;
            }

            if (mar_txtUser[3].Text == String.Empty)
            {
                System.Media.SystemSounds.Exclamation.Play();
                MessageBox.Show("Please enter Serial Number.");
                return -1;
            }

            if (mar_txtUser[4].Text == String.Empty)
            {
                System.Media.SystemSounds.Exclamation.Play();
                MessageBox.Show("Please enter Temperature.");
                return -1;
            }

            return 0;
        }

        public void RunTest()
        {
            /*
                        if (CheckPreTestRunCondition() == -1)
                            return;
            */
            TestMain.Self.UpdateTxtProgressInfo("                ", 2);
            TestMain.Self.UpdateTxtProgressInfo("****************", 2);
            TestMain.Self.UpdateTxtProgressInfo("                ", 2);
            TestMain.Self.UpdateTxtProgressInfo("Serial Number: " + mar_txtUser[3].Text, 2);
            SetDatalogParam();
            SetTempRef();

            foreach (TestBase tst in m_TestBaseCollIF.m_TestObjColl)
                tst.ClearBeforeRunDisplay();

            mar_btnprogress.Text = "TEST IN PROGRESS";
            mar_btnprogress.BackColor = Color.LightBlue;

            mar_usrbtn[0].Enabled = false;

            Application.DoEvents();

            int passfail = 1;
            foreach (TestBase tst in m_TestBaseCollIF.m_TestObjColl)
            {
                TestMain.Self.UpdateTxtProgressInfo("                ", 2);
                tst.ExecuteTest();
                passfail = passfail & tst.PassOrFail();
                if (passfail == 0)
                {
                    m_TestBaseCollIF.RunPostTest();
                    break;
                }
            }

            m_TestBaseCollIF.AreAllTestPass();
            m_TestBaseCollIF.PostTestDGVUpdate();
            
            if (passfail == 1)
            {
                m_TestCounterPass++;
                mar_btnprogress.Text = "PASS";
                mar_btnprogress.BackColor = Color.LightGreen;
                mar_txtprogress[0].Text = m_TestCounterPass.ToString();
            }
            else
            {
                m_TestCounterFail++;
                mar_btnprogress.Text = "FAIL";
                mar_btnprogress.BackColor = Color.Red;
                mar_txtprogress[1].Text = m_TestCounterFail.ToString();
            }

            float testtotal = m_TestCounterPass + m_TestCounterFail;

            float yield = (m_TestCounterFail / testtotal);

            mar_txtprogress[2].Text = yield.ToString();

            //m_Datalog.AddtoDataLog(" "); // + mar_btCmd[0].Text);
            m_Datalog.LogData(mar_btnprogress.Text);

            mar_txtprogress[2].Text = ((m_TestCounterFail / (m_TestCounterPass + m_TestCounterFail)) * 100).ToString();

            mar_usrbtn[0].Enabled = true;

            //doing a post clear display
            foreach (TestBase tst in m_TestBaseCollIF.m_TestObjColl)
                tst.ClearTextAfterRun();

            mar_txtUser[3].Text = "";
            mar_txtUser[3].Select();
            //mar_usrbtn[0].Select();
        }

    }
}
