﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace HOB_CM_Test
{
    class TestDataLog
    {
        string str_data_log, job_number, op_name, p_number, s_number;
        string m_programID;
        ConfigData m_config = new ConfigData();
        public TestDataLog()
        {
            str_data_log = "";
            m_config.LoadConfigFile();
        }

        public void LogData(string status)
        {
            //header
            //string file_sdt = DateTime.Now.ToString("MM.dd.yyyy hh:mm:ss");
            string file_sdt = DateTime.Now.ToString("MM.dd.yyyy");
            file_sdt = file_sdt.Replace(".", "");
            //file_sdt = file_sdt.Replace(":", "");
            //file_sdt = file_sdt.Replace(" ", "_");
            file_sdt = file_sdt + "_JN_" + job_number + "_OP_" + op_name + " ";
            //file_sdt = file_sdt + "_" + m_programID;
            file_sdt = file_sdt + ".csv";
            
            if (TestMain.Self.get_testmode().ToString() == "Final")
            {
                file_sdt = m_config.datalog_directory + file_sdt;
            }
            else
            {
                file_sdt = m_config.prelim_test_datalog_directory + file_sdt;
            }
            

            StreamWriter sw_logfile;

            if (!File.Exists(file_sdt))
            {
                sw_logfile = new StreamWriter(file_sdt);
                sw_logfile.WriteLine("Time,SerialNo,PartNo,FGTemp(C),PackTemp(C),Status1,Status2,Status3,Status4,VoltDelta(mV),FullCap(mAh),DesignCap(mAh),RemainingCap(mAh),InstantCurrent(mA),LatchSwitch,Load&Check Serial,Charge1A(A),Discharge2A(mA),PackVoltage(V),Discharge8A(mA),PackVoltage(V),SwOffOn,LED,");        // Header for new log file
            }
            else
            {
                sw_logfile = File.AppendText(file_sdt);
            }

            str_data_log = DateTime.Now.ToString("MM/dd/yyyy HH:mm:ss") + "," + s_number + "," + p_number + "," + str_data_log;
            str_data_log += status;

            sw_logfile.WriteLine(str_data_log);
            sw_logfile.Close();

            str_data_log = "";
        }

        public void StoreCANMessage(string canmessage)
        {
            string file_sdt = DateTime.Now.ToString("MMddyyyy hhmmss");
            file_sdt = file_sdt.Replace(" ", "_");
            file_sdt =  "CAN_JN_" + job_number + "_SN_" + s_number + "_" + file_sdt;
            file_sdt = file_sdt + ".txt";
            file_sdt = m_config.can_datalog_directory + file_sdt;
            StreamWriter sw_logfile;

            if (!File.Exists(file_sdt))
            {
                sw_logfile = new StreamWriter(file_sdt);
            }
            else
            {
                sw_logfile = File.AppendText(file_sdt);
            }

            sw_logfile.WriteLine(canmessage);
            sw_logfile.Close();
        }

        public void AddtoDataLog(string logdata)
        {
            str_data_log += logdata + ",";
        }

        public void SetJobNumber(string jn)
        {
            job_number = jn;
        }

        public void SetOperator(string opname)
        {
            op_name = opname;
        }

        public void SetProgramID(string id)
        {
            m_programID = id;
        }

        public void PartNumber(string pn)
        {
            p_number = pn;
        }

        public void SerialNumber(string sn)
        {
            s_number = sn;
        }
    }
}
