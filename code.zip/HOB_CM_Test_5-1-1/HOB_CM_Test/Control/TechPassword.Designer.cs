﻿namespace HOB_CM_Test.Control
{
    partial class TechPassword
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTechPassword = new System.Windows.Forms.Label();
            this.txtTechPassword = new System.Windows.Forms.TextBox();
            this.btnTechPassword = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblTechPassword
            // 
            this.lblTechPassword.AutoSize = true;
            this.lblTechPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTechPassword.Location = new System.Drawing.Point(81, 24);
            this.lblTechPassword.Name = "lblTechPassword";
            this.lblTechPassword.Size = new System.Drawing.Size(128, 13);
            this.lblTechPassword.TabIndex = 0;
            this.lblTechPassword.Text = "Enter Tech Password";
            // 
            // txtTechPassword
            // 
            this.txtTechPassword.Location = new System.Drawing.Point(77, 46);
            this.txtTechPassword.Name = "txtTechPassword";
            this.txtTechPassword.Size = new System.Drawing.Size(132, 20);
            this.txtTechPassword.TabIndex = 1;
            // 
            // btnTechPassword
            // 
            this.btnTechPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTechPassword.Location = new System.Drawing.Point(94, 80);
            this.btnTechPassword.Name = "btnTechPassword";
            this.btnTechPassword.Size = new System.Drawing.Size(92, 27);
            this.btnTechPassword.TabIndex = 2;
            this.btnTechPassword.Text = "Enter";
            this.btnTechPassword.UseVisualStyleBackColor = true;
            // 
            // TechPassword
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.btnTechPassword);
            this.Controls.Add(this.txtTechPassword);
            this.Controls.Add(this.lblTechPassword);
            this.Name = "TechPassword";
            this.Size = new System.Drawing.Size(286, 133);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTechPassword;
        private System.Windows.Forms.TextBox txtTechPassword;
        private System.Windows.Forms.Button btnTechPassword;
    }
}
