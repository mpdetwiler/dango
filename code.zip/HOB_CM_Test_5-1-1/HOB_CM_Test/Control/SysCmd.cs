﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Windows.Forms;

namespace HOB_CM_Test
{
    class SysCmd
    {
        public string ms_cmd_output, ms_cmd_error;
        TextBox m_TxtOutput;


        public SysCmd()
        {

        }

        public void SetTextbox(ref TextBox tb)
        {
            m_TxtOutput = tb;
        }

        public string GetOutputString()
        {
            return ms_cmd_output;
        }

        /* cmd: should be "cmd.exe" for DOS system command
         * arg: used for user command such as dir, or any command line.
         * arg: for example, dir c:\ should be "c/ DIR c:\"
         * RunCmd ("cmd.exe", "c/ DIR c:\"
         * 
         * 
         * */
        public void RunCmd(string cmd, string arg)
        {
            ms_cmd_output = "";
            ms_cmd_error = "";

            Process process = new Process();
            process.StartInfo.FileName = cmd;
            process.StartInfo.Arguments = arg; // Note the /c command (*)
            process.StartInfo.UseShellExecute = false;
            process.StartInfo.RedirectStandardOutput = true;
            process.StartInfo.RedirectStandardError = true;
            //process.StartInfo.CreateNoWindow = true;
            process.Start();
            //* Read the output 
            ms_cmd_output = process.StandardOutput.ReadToEnd();
            Console.WriteLine(ms_cmd_output);
            ms_cmd_error = process.StandardError.ReadToEnd();
            Console.WriteLine(ms_cmd_error);
            process.WaitForExit(10000);
        }

        public void RunCmdLineRead(string cmd, string arg)
        {
            ms_cmd_output = "";
            ms_cmd_error = "";

            Process process = new Process();

            process.StartInfo.UseShellExecute = false;
            process.StartInfo.FileName = cmd;
            process.StartInfo.Arguments = arg;
            process.StartInfo.CreateNoWindow = true;
            process.StartInfo.RedirectStandardOutput = true;
            process.Start();

            string standard_output;
            while ((standard_output = process.StandardOutput.ReadLine()) != null)
            {
                if (standard_output.Contains("xx"))
                {
                    //do something
                    break;
                }
            }
        }

        public void RunCmdLineTimeout(string cmd, string arg, int timeout)      // Time in milliseconds
        {
            ms_cmd_output = "";
            ms_cmd_error = "";

            Process process = new Process();
            process.StartInfo.FileName = cmd;
            process.StartInfo.Arguments = arg; // Note the /c command (*)
            process.StartInfo.UseShellExecute = false;
            process.StartInfo.RedirectStandardOutput = true;
            process.StartInfo.RedirectStandardError = true;
            process.StartInfo.CreateNoWindow = true;
            process.Start();
            //* Read the output 
            //ms_cmd_output = process.StandardOutput.ReadToEnd();
            //Console.WriteLine(ms_cmd_output);
            //ms_cmd_error = process.StandardError.ReadToEnd();
            //Console.WriteLine(ms_cmd_error);
            process.WaitForExit(timeout);

            process.Kill();
        }


    }
}
