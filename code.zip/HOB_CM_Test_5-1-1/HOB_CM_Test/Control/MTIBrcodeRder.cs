﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HOB_CM_Test
{
    public partial class MTIBrcodeRder : Form
    {
        TextBox m_stMTIBarCode;

        public MTIBrcodeRder()
        {
            InitializeComponent();
        }

        public void SetMTIBarCode(ref TextBox sn)
        {
            m_stMTIBarCode = sn;
        }

        private void btMTIBarcode_Click(object sender, EventArgs e)
        {
            if (txtMTIBarcode.Text == "")
            {
                MessageBox.Show("The field is empty.  Please use the Barcode Reader to enter the MTI number.");
                m_stMTIBarCode.Text = "";
                this.Close();
            }
            else
            {
                m_stMTIBarCode.Text = txtMTIBarcode.Text;
                this.Close();
            }
        }

    }
}
