﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HOB_CM_Test
{
    class LoadProgramColl : TestBaseCollectionIF
    {
        TestClassProgMicro TestProgMicro = new TestClassProgMicro();

        public LoadProgramColl()
        {
            m_TestObjColl.Add(TestProgMicro);
        }
    }
}
