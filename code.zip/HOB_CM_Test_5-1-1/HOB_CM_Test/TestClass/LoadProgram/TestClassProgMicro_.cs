﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HOB_CM_Test
{
    class TestClassProgMicro_ : TestBase
    {
        public override void ExecuteTest()
        {
            TestMain.Self.UpdateTxtProgressInfo("Program Microprocessor.", 2);
            TestMain.Self.UpdateTxtProgressInfo("Program Microprocessor.", 0);
            TestMain.Self.UpdateTxtProgressInfo("Program Microprocessor.", 1);
            SetPassFail(0);
            Application.DoEvents();
        }
    }
}
