﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HOB_CM_Test
{
    class TestClassTestTemperature : TestBase
    {
        public override void ExecuteTest()
        {
            TestMain.Self.UpdateTxtProgressInfo("Temperature Test.", 2);
            TestMain.Self.UpdateTxtProgressInfo("Temperature Test", 0);
            TestMain.Self.UpdateTxtProgressInfo("Temperature Test", 1);
            if(PassOrFail()==1)
                SetPassFail(0);
            else
                SetPassFail(1);
            AddtoDataLog("Temperature");
            Application.DoEvents();
        }
    }
}
