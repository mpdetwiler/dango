﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Forms;

namespace HOB_CM_Test
{
    class TestClassTestButton : TestBase
    {
        DialogResult result;
        bool testresult = true;
        byte[] readdata;
        public override void ExecuteTest()
        {
            TestMain.Self.UpdateTxtProgressInfo("Button Test:", 2);

            result = MessageBox.Show("Press button and hold. Click OK to continue.", "Confirmation", MessageBoxButtons.OK);
            if (result == DialogResult.OK)
            {
                m_CANBusIF.CAN_Messages(0x04, 0x00);
                readdata = m_CANBusIF.CAN_rx();
                if (readdata[0] == 0)
                    testresult = true;
                else
                    testresult = false;
            }

            if (testresult == true)
            {
                result = MessageBox.Show("Release button. Click OK to continue.", "Confirmation", MessageBoxButtons.OK);
                if (result == DialogResult.OK)
                {
                    m_CANBusIF.CAN_Messages(0x04, 0x00);
                    readdata = m_CANBusIF.CAN_rx();
                    if (readdata[0] == 1)
                        testresult = true;
                    else
                        testresult = false;
                }
            }

            if (testresult)
            {
                TestMain.Self.UpdateTxtProgressInfo("Button", 1);
                SetPassFail(1);
                AddtoDataLog("P");
            }
            else
            {
                TestMain.Self.UpdateTxtProgressInfo("Button", 0);
                SetPassFail(0);
                AddtoDataLog("F");
            }
            Application.DoEvents();
        }
    }
}
