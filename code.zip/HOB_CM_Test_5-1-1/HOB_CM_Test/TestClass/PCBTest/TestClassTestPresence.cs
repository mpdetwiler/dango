﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace HOB_CM_Test
{
    class TestClassTestPresence : TestBase
    {
        public override void ExecuteTest()
        {
            byte[] readdata;
            TestMain.Self.UpdateTxtProgressInfo("Presence In Test:", 2);
            try
            {
                
                TestMain.Self.UpdateTxtProgressInfo("Presence-In TEST:", 2);
                m_CANBusIF.CAN_Messages(0x0E, 0x01);            //Presence pin high
                Thread.Sleep(1000);
                readdata = m_CANBusIF.CAN_rx();                //data[0] should be 1
                if (readdata[0] == 1)
                {
                    //fail
                    TestMain.Self.UpdateTxtProgressInfo("Presence-In High", 1);
                }
                else
                {
                    //pass
                    TestMain.Self.UpdateTxtProgressInfo("Presence-In High", 0);
                }
                m_CANBusIF.CAN_Messages(0x0E, 0x00);            //Presence pin low
                Thread.Sleep(1000);
                readdata = m_CANBusIF.CAN_rx();                //data[0] should be 0
                if (readdata[0] == 0)
                {
                    //fail
                    TestMain.Self.UpdateTxtProgressInfo("Presence-In Low", 1);
                }
                else
                {
                    //pass
                    TestMain.Self.UpdateTxtProgressInfo("Presence-In Low", 0);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Presence-In Test Error: " + e.Message);
            }




            TestMain.Self.UpdateTxtProgressInfo("Presence In Test", 0);
            TestMain.Self.UpdateTxtProgressInfo("Presence In Test", 1);
            SetPassFail(1);
            AddtoDataLog("Presence");
            Application.DoEvents();
        }
    }
}
