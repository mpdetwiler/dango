﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HOB_CM_Test
{
    class TestClassTestInEoc : TestBase
    {
        public override void ExecuteTest()
        {
            TestMain.Self.UpdateTxtProgressInfo("In EOC Test.", 2);
            TestMain.Self.UpdateTxtProgressInfo("In EOC Test", 0);
            TestMain.Self.UpdateTxtProgressInfo("In EOC Test", 1);
            SetPassFail(1);
            AddtoDataLog("In EOC");
            Application.DoEvents();
        }
    }
}
