﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HOB_CM_Test
{
    class TestClassTestBQ34Current : TestBase
    {
        public override void ExecuteTest()
        {
            TestMain.Self.UpdateTxtProgressInfo("BQ34 Current Test.", 2);
            TestMain.Self.UpdateTxtProgressInfo("BQ34 Current Test", 0);
            TestMain.Self.UpdateTxtProgressInfo("BQ34 CUrrent Test", 1);
            SetPassFail(1);
            AddtoDataLog("BQ34 Current");
            Application.DoEvents();
        }
    }
}
