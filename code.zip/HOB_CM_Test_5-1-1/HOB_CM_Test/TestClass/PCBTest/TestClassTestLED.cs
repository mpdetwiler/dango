﻿using System.Windows.Forms;
using System.Drawing;
using System.Threading;

namespace HOB_CM_Test
{
    class TestClassTestLED : TestBase
    {
        DialogResult result;
        bool testresult = true;
        public override void ExecuteTest()
        {

            TestMain.Self.UpdateTxtProgressInfo("LED Test:", 2);
            m_CANBusIF.CAN_Messages(0x03, 0x00);
            //can_message.CAN_Message(0x03, 0x00);   //OFF all LED
            Thread.Sleep(1000);
            m_CANBusIF.CAN_Messages(0x03, 0x01);   //ON all LED
            Thread.Sleep(1000);
            result = MessageBox.Show("ALL LED lights ON?", "Confirmation", MessageBoxButtons.YesNo);  //ask operator to check LED - ON
            if (result == DialogResult.Yes)
                testresult = true;
            else
                testresult = false;

            if (testresult)
            {
                m_CANBusIF.CAN_Messages(0x03, 0x00);   //OFF all LED
                Thread.Sleep(1000);
                result = MessageBox.Show("ALL LED lights OFF?", "Confirmation", MessageBoxButtons.YesNo);  //ask operator to check  LED - OFF
                if (result == DialogResult.Yes)
                    testresult = true;
                else
                    testresult = false;
            }

            if (testresult)
            {
                TestMain.Self.UpdateTxtProgressInfo("LED", 1);
                SetPassFail(1);
                AddtoDataLog("P");
            }
            else
            {
                TestMain.Self.UpdateTxtProgressInfo("LED", 0);
                SetPassFail(0);
                AddtoDataLog("F");
            }
            
            Application.DoEvents();
        }
    }
}
