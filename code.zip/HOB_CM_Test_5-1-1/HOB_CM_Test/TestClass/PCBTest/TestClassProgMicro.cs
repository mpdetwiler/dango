﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HOB_CM_Test
{
    class TestClassProgMicro : TestBase
    {
        public override void ExecuteTest()
        {
            UUTCommand uut_cmd = new UUTCommand();
            TestMain.Self.UpdateTxtProgressInfo("Program Microcontroller:", 2);
            if(uut_cmd.ProgramBoard() == 1)
            {
                TestMain.Self.UpdateTxtProgressInfo("Program.", 1);
                SetPassFail(1);
                AddtoDataLog("P");
            }
            else
            {
                TestMain.Self.UpdateTxtProgressInfo("Program.", 0);
                SetPassFail(0);
                AddtoDataLog("F");
            }
            Application.DoEvents();
        }
    }
}
