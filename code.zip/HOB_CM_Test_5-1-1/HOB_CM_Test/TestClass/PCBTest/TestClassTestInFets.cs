﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HOB_CM_Test
{
    class TestClassTestInFets : TestBase
    {
        public override void ExecuteTest()
        {
            TestMain.Self.UpdateTxtProgressInfo("Address In FET Test.", 2);
            TestMain.Self.UpdateTxtProgressInfo("Address In FET Test", 0);
            TestMain.Self.UpdateTxtProgressInfo("Address In FET Test", 1);
            SetPassFail(1);
            AddtoDataLog("In FET");
            Application.DoEvents();
        }
    }
}
