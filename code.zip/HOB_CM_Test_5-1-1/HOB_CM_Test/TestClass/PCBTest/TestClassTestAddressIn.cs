﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace HOB_CM_Test
{
    class TestClassTestAddressIn : TestBase
    {
        public override void ExecuteTest()
        {
            try
            {
                byte[] readdata;
                decimal voltread;
                double voltconv;
                TestMain.Self.UpdateTxtProgressInfo("Address-In TEST:", 2);
                m_CANBusIF.CAN_Messages(0x05, 0x01);
                Thread.Sleep(1000);
                readdata = m_CANBusIF.CAN_rx();
                voltread = (decimal)BitConverter.ToInt16(readdata, 0);
                voltconv = (float)(voltread / 4096) * 3.3;
                if (voltconv > 3.365 | voltconv < 3.135)
                {
                    TestMain.Self.UpdateTxtProgressInfo("Address-In reading: " + voltconv.ToString(), 1);
                    SetPassFail(1);
                    AddtoDataLog(voltconv.ToString());
                }
                else
                {
                    TestMain.Self.UpdateTxtProgressInfo("Address-In reading: " + voltconv.ToString(), 0);
                    SetPassFail(0);
                    AddtoDataLog(voltconv.ToString());
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Address-in Test Error: " + e.Message);
            }
            Application.DoEvents();
        }
    }
}
