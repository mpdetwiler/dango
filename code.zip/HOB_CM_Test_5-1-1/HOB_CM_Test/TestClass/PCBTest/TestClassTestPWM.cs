﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace HOB_CM_Test
{
    class TestClassTestPWM : TestBase
    {
        public override void ExecuteTest()
        {
            double packvolt = 0;
            bool testresult = true;
            TestMain.Self.UpdateTxtProgressInfo("PWM Test:", 2);
            try
            {
                m_CANBusIF.CAN_Messages(0x0A, 0x00);            //Charge discharge FET OFF
                Thread.Sleep(500);
                m_CANBusIF.CAN_Messages(0x08, 0x01);            //Discharge FET ON
                Thread.Sleep(500);
                m_CANBusIF.CAN_Messages(0x0B, 0x01);            //PWM high
                Thread.Sleep(500);
                //double packvolt = ec.MCReadAnIn(ei.DBoard, 0); //measure output, if low fail
                if (packvolt > 5)
                {
                    testresult = true;
                    TestMain.Self.UpdateTxtProgressInfo("PWM reading high: " + packvolt.ToString(), 1);
                }
                else
                {
                    testresult = false;
                    TestMain.Self.UpdateTxtProgressInfo("PWM reading high: " + packvolt.ToString(), 0);
                }

                if (testresult)
                {
                    m_CANBusIF.CAN_Messages(0x0B, 0x00);            //PWM low
                    Thread.Sleep(500);
                    //packvolt = ec.MCReadAnIn(ei.DBoard, 0);                                                //measure output, if high fail
                    if (packvolt < 1)
                    {
                        testresult = true;
                        TestMain.Self.UpdateTxtProgressInfo("PWM reading low: " + packvolt.ToString(), 1);
                    }
                    else
                    {
                        testresult = false;
                        TestMain.Self.UpdateTxtProgressInfo("PWM reading low: " + packvolt.ToString(), 0);
                    }
                }
                m_CANBusIF.CAN_Messages(0x08, 0x00);            //Charge FET OFF

                if (testresult)
                {
                    SetPassFail(1);
                    AddtoDataLog("P");
                }
                else
                {
                    SetPassFail(0);
                    AddtoDataLog("F");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("PWM Test Error: " + e.Message);
            }

            Application.DoEvents();
        }
    }
}
