﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HOB_CM_Test
{
    class PCBTestColl : TestBaseCollectionIF
    {

        TestClassTestLED TestLED = new TestClassTestLED();
        TestClassTestButton TestButton = new TestClassTestButton();
        TestClassTestBQ34Current TestBQ34Current = new TestClassTestBQ34Current();
        TestClassTestCDFET TestCDFET = new TestClassTestCDFET();
        TestClassTestInEoc TestInEoc = new TestClassTestInEoc();
        TestClassTestInFets TestInFets = new TestClassTestInFets();
        TestClassTestPackCurrent TestPackCurrent = new TestClassTestPackCurrent();
        TestClassTestPresence TestPresence = new TestClassTestPresence();
        TestClassTestPWM TestPWM = new TestClassTestPWM();
        TestClassTestTemperature TestTemperature = new TestClassTestTemperature();
        TestClassProgMicro TestProgMicro = new TestClassProgMicro();
        TestClassTestAddressIn TestAddressIn = new TestClassTestAddressIn();

        public PCBTestColl()
        {
            m_TestObjColl.Add(TestProgMicro);
            m_TestObjColl.Add(TestLED);
            m_TestObjColl.Add(TestButton);
            m_TestObjColl.Add(TestAddressIn);
            m_TestObjColl.Add(TestPWM);
//            m_TestObjColl.Add(TestBQ34Current);
//            m_TestObjColl.Add(TestCDFET);
//            m_TestObjColl.Add(TestInEoc);
//            m_TestObjColl.Add(TestInFets);
//            m_TestObjColl.Add(TestPackCurrent);
//            m_TestObjColl.Add(TestPresence);
//            m_TestObjColl.Add(TestTemperature);
        }
    }
}
