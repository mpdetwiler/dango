﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace HOB_CM_Test
{
    class TestClassTestPresentPin : TestBase
    {
        DialogResult result;
        bool testresult = true;
        int m_output_idx = 4;
        int m_try_max = 20;
        double m_pres_out_thrhold = 0.5;
        double m_pres_on_thrhold = 25.0;


        public override void ExecuteTest()
        {
            double output_voltage = 30;
            TestMain.Self.UpdateTxtProgressInfo("Present Pin Test:", 2);

            //result = MessageBox.Show("Turn the Presence Pin to Off and click OK button to continue.", "Task", MessageBoxButtons.OK);  //ask operator to turn the Presence Pin to OFF
            TestMain.Self.presence_pin(1);
            Thread.Sleep(3000);
            TestMain.Self.load_relay(1);
            Thread.Sleep(200);
            m_DCLoadIF.get_voltage_curr_data();
            output_voltage = m_DCLoadIF.m_DC_Voltage_val;
            Thread.Sleep(200);
            TestMain.Self.load_relay(0);

            if (output_voltage < m_pres_out_thrhold)
            {
                testresult = true;
            }
            else
            {
                testresult = false;
            }

            if (testresult)
            {
                //result = MessageBox.Show("Turn the Presence Pin to On and click OK button to continue.", "Task", MessageBoxButtons.OK);  //ask operator to turn the Presence Pin to On
                TestMain.Self.presence_pin(0);
                TestMain.Self.load_relay(1);
                Thread.Sleep(1000);
                m_DCLoadIF.get_voltage_curr_data();
                output_voltage = m_DCLoadIF.m_DC_Voltage_val;
                Thread.Sleep(200);
                //TestMain.Self.load_relay(0);
                if (output_voltage > m_pres_on_thrhold)
                {
                    testresult = true;
                }
                else
                {
                    testresult = false;
                }

            }
            if (testresult)
            {
                TestMain.Self.UpdateTxtProgressInfo("Present Pin Test", 1);
                SetPassFail(1);
                AddtoDataLog("P");
            }
            else
            {
                TestMain.Self.UpdateTxtProgressInfo("Present Pin Test", 0);
                SetPassFail(0);
                AddtoDataLog("F");
            }
        }
    }
}
