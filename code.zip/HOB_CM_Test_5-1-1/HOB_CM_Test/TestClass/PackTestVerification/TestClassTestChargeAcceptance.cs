﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace HOB_CM_Test
{
    class TestClassTestChargeAcceptance : TestBase
    {
        double m_curr_limit = .05; //5%
        double m_curr_pro = 1.0;    //1.0 A
        double m_volt_pro = 30;     //30.0 V
        int m_output_idx = 0;

        public override void ExecuteTest()
        {
            TestMain.Self.UpdateTxtProgressInfo("Charge Acceptance Test:", 2);
            m_PwrSupDev.Supply_Out_Current(m_curr_pro.ToString());
            m_PwrSupDev.Supply_Out_Volt(m_volt_pro.ToString());

            TestMain.Self.load_relay(0);
            TestMain.Self.supply_relay(1);      // Turn on PWR supply relay
            Thread.Sleep(500);
            m_PwrSupDev.Supply_Output_ON();

            Thread.Sleep(3000);
            double output_volt = m_PwrSupDev.Meas_Supply_Voltage();
            double output_curr = m_PwrSupDev.Meas_Supply_Current();


            m_PwrSupDev.Supply_Output_OFF();
            Thread.Sleep(500);
            TestMain.Self.supply_relay(0);      // Turn off PWR supply relay

            if ((output_curr > m_curr_pro * (1.0 - m_curr_limit)) && (output_curr < m_curr_pro * (1.0 + m_curr_limit)))
            {
                TestMain.Self.UpdateTxtProgressInfo("Charge 1A: " + output_curr.ToString("0.00") + " A", 1);
                SetPassFail(1);
                AddtoDataLog(output_curr.ToString("0.00") + " A");
            }
            else
            {
                TestMain.Self.UpdateTxtProgressInfo("Charge 1A: " + output_curr.ToString("0.00") + " A", 0);
                SetPassFail(0);
                AddtoDataLog(output_curr.ToString("0.00") + " A");
            }

        }
    }
}
