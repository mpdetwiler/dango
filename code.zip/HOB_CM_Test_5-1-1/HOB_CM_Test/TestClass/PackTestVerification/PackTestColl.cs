﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HOB_CM_Test
{
    class PackTestColl : TestBaseCollectionIF
    {
        TestClassTestCAN TestCAN = new TestClassTestCAN();
        TestClassTestChargeAcceptance ChargeAcceptance = new TestClassTestChargeAcceptance();
        TestClassTestDischarge2A Discharge2A = new TestClassTestDischarge2A();
        TestClassTestDischarge8A Discharge8A = new TestClassTestDischarge8A();
        TestClassTestPresentPin PresentPin = new TestClassTestPresentPin();
        TestClassTestVerifyLED VerifyLED = new TestClassTestVerifyLED();


        public PackTestColl()
        {
            m_TestObjColl.Add(TestCAN);
            m_TestObjColl.Add(ChargeAcceptance);
            m_TestObjColl.Add(Discharge2A);
            m_TestObjColl.Add(Discharge8A);
            m_TestObjColl.Add(PresentPin);
            m_TestObjColl.Add(VerifyLED);
        }
    }
}
