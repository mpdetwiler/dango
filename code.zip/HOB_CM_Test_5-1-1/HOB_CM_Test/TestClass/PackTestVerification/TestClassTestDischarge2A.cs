﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace HOB_CM_Test
{
    class TestClassTestDischarge2A : TestBase
    {
        double m_curr_pro = 2000;
        double m_curr_lim = .05;    //5%
        double m_volt_lim = .50;    //50%
        int m_curr_delay = 500;
        int m_output_idx = 2;
        
        public override void ExecuteTest()
        {
            //m_MccDaqIF.ConnectPackToLoad(1);
            //System.Threading.Thread.Sleep(2000);
            //m_MccDaqIF.ConnectPackToBus(1);
            //System.Threading.Thread.Sleep(2000);
            double prev_volt_reading = 0;
            double prev_curr_reading = 0;
            double init_volt_reading = 0;
            
            TestMain.Self.UpdateTxtProgressInfo("Discharge 2A:", 2);
            m_DCLoadIF.set_current((int)m_curr_pro);

            TestMain.Self.load_relay(1);       //Turn on Electronic Load relay
            Thread.Sleep(500);
            m_DCLoadIF.load_on();

            Thread.Sleep(m_curr_delay);


            m_DCLoadIF.get_voltage_curr_data();
            double output_voltage = m_DCLoadIF.m_DC_Voltage_val;
            double output_curr = m_DCLoadIF.m_DC_Curr_val * 1000;
            init_volt_reading = output_voltage;
            prev_volt_reading = output_voltage;
            prev_curr_reading = output_curr;

            for (int x = 0; x < 5; x++)
            {
                m_DCLoadIF.get_voltage_curr_data();
                output_voltage = m_DCLoadIF.m_DC_Voltage_val;
                output_curr = m_DCLoadIF.m_DC_Curr_val * 1000;
                if (output_curr < prev_curr_reading)
                    prev_curr_reading = output_curr;
                if (output_voltage < prev_volt_reading)
                    prev_volt_reading = output_voltage;
                Thread.Sleep(500);
            }


            m_DCLoadIF.load_off();
            Thread.Sleep(500);
            TestMain.Self.load_relay(0);      //Turn off Electronic Load relay

            if ((prev_curr_reading > m_curr_pro * (1.0 - m_curr_lim)) && (prev_curr_reading < m_curr_pro * (1.0 + m_curr_lim)))
            {
                TestMain.Self.UpdateTxtProgressInfo("Discharge current at 2A: " + prev_curr_reading.ToString("0.00") + " mA", 1);
                SetPassFail(1);
                AddtoDataLog(prev_curr_reading.ToString("0.00") + " mA");
            }
            else
            {
                TestMain.Self.UpdateTxtProgressInfo("Discharge 2A: " + prev_curr_reading.ToString("0.00") + " mA", 0);
                SetPassFail(0);
                AddtoDataLog(prev_curr_reading.ToString("0.00") + " mA");
            }

            if (prev_volt_reading > init_volt_reading * (1.0 - m_volt_lim))
            {
                TestMain.Self.UpdateTxtProgressInfo("Discharge voltage at 2A: " + prev_volt_reading.ToString("0.00") + " V", 1);
                SetPassFail(1);
                AddtoDataLog(prev_volt_reading.ToString("0.00") + " V");
            }
            else
            {
                TestMain.Self.UpdateTxtProgressInfo("Discharge voltage at 2A: " + prev_volt_reading.ToString("0.00") + " V", 0);
                SetPassFail(0);
                AddtoDataLog(prev_volt_reading.ToString("0.00") + " V");
            }

        }
    }
}
