﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HOB_CM_Test
{
    class TestClassTestVerifyLED : TestBase
    {
        DialogResult result;
        bool testresult = true;
        public override void ExecuteTest()
        {
            TestMain.Self.UpdateTxtProgressInfo("LED Test:", 2);
            result = MessageBox.Show("Press key pad button. At least one LED should light up. Is there a LED light up?", "Task", MessageBoxButtons.YesNo);  //ask operator to check LED - ON
            if(result == DialogResult.Yes)
            {
                TestMain.Self.UpdateTxtProgressInfo("LED", 1);
                SetPassFail(1);
                AddtoDataLog("P");
            }
            else
            {
                TestMain.Self.UpdateTxtProgressInfo("LED", 0);
                SetPassFail(0);
                AddtoDataLog("F");
            }
            Application.DoEvents();
        }
    }
}
