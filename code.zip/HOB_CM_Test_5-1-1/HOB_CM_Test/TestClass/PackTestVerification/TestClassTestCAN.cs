﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HOB_CM_Test
{
    class TestClassTestCAN : TestBase
    {
        UUTCommand uut_cmd = new UUTCommand();
        double m_temp_lim = .20;    //15%
        int m_output_idx = 5;
        double m_Cell_MaxMin_delta = 200;  //mV
        double m_Max_charge_percentage = 0.30;
        private static string temperatureref;

        public TestClassTestCAN()
        {

        }

        public string SetTemperatureRef
        {
            get { return temperatureref; }
            set { temperatureref = value; }
        }

        public override void ExecuteTest()
        {
            int fuga_pf, pack_pf;
            int st1, st2, st3, st4, sw;
            int cell_delta, charge_percent;
            int inst_ma;
            int srl_read;

            m_curr_temp = double.Parse(temperatureref, System.Globalization.CultureInfo.InvariantCulture);//String(m_userTxtInfo[4].Text);
            
            TestMain.Self.UpdateTxtProgressInfo("CAN Test:", 2);
            uut_cmd.CANVerification();
            m_Datalog.StoreCANMessage(uut_cmd.m_final_test_output);

            double fuga_temp = uut_cmd.m_fuga_temp;
            TestMain.Self.UpdateTxtProgressInfo("FG Temp: " + fuga_temp.ToString("0.00") + " C", 2);

            double pack_temp = uut_cmd.m_pack_temp;
            TestMain.Self.UpdateTxtProgressInfo("Pack Temp: " + pack_temp.ToString("0.00") + " C", 2);

            double remaining_capacity = uut_cmd.m_remaining_capacity;
            TestMain.Self.UpdateTxtProgressInfo("Remaining Capacity: " + remaining_capacity.ToString("0.00") + " mAh", 2);

            double design_capacity = uut_cmd.m_design_capacity;
            TestMain.Self.UpdateTxtProgressInfo("Design Capacity: " + design_capacity.ToString("0.00") + " mAh", 2);

            double full_capacity = uut_cmd.m_full_capacity;
            TestMain.Self.UpdateTxtProgressInfo("Full Capacity: " + full_capacity.ToString("0.00") + " mAh", 2);

            double instant_current = uut_cmd.m_instant_current;
            TestMain.Self.UpdateTxtProgressInfo("Instantaneous Current: " + instant_current.ToString("0.00") + " mA", 2);

            string serial_read = uut_cmd.m_load_check_serialnum;
            TestMain.Self.UpdateTxtProgressInfo("SerialNum: " + serial_read, 2);

            if ((fuga_temp > m_curr_temp * (1 - m_temp_lim)) && (fuga_temp < m_curr_temp * (1 + m_temp_lim)))
            {
                fuga_pf = 1;
                TestMain.Self.UpdateTxtProgressInfo("FG Temp: " + fuga_temp.ToString("0.00") + " °C", 1);
                //SetPassFail(1);
                AddtoDataLog(fuga_temp.ToString("0.00") + " °C");
            }
            else
            {
                fuga_pf = 0;
                TestMain.Self.UpdateTxtProgressInfo("FG Temp: " + fuga_temp.ToString("0.00") + " °C", 0);
                //SetPassFail(0);
                AddtoDataLog(fuga_temp.ToString("0.00") + " °C");
            }

            if ((pack_temp > m_curr_temp * (1 - m_temp_lim)) && (pack_temp < m_curr_temp * (1 + m_temp_lim)))
            {
                pack_pf = 1;
                TestMain.Self.UpdateTxtProgressInfo("Pack Temp: " + pack_temp.ToString("0.00") + " °C", 1);
                //SetPassFail(1);
                AddtoDataLog(pack_temp.ToString("0.00") + " °C");
            }
            else
            {
                pack_pf = 0;
                TestMain.Self.UpdateTxtProgressInfo("Pack Temp: " + pack_temp.ToString("0.00") + " °C", 0);
                //SetPassFail(0);
                AddtoDataLog(pack_temp.ToString("0.00") + " °C");
            }

            //m_txtDatalogging.AppendText(m_AeryonCmd.m_final_test_output);

            if (uut_cmd.m_status1 == "0x0")
            {
                st1 = 1;
                TestMain.Self.UpdateTxtProgressInfo("Status 1: " + uut_cmd.m_status1, 1);
                AddtoDataLog(uut_cmd.m_status1);
            }
            else
            {
                st1 = 0;
                TestMain.Self.UpdateTxtProgressInfo("Status 1: " + uut_cmd.m_status1, 0);
                AddtoDataLog(uut_cmd.m_status1);
            }
            if (uut_cmd.m_status2 == "0x0")
            {
                st2 = 1;
                TestMain.Self.UpdateTxtProgressInfo("Status 2: " + uut_cmd.m_status2, 1);
                AddtoDataLog(uut_cmd.m_status2);
            }
            else
            {
                st2 = 0;
                TestMain.Self.UpdateTxtProgressInfo("Status 2: " + uut_cmd.m_status2, 0);
                AddtoDataLog(uut_cmd.m_status2);
            }

            if (uut_cmd.m_status3 == "0x40")
            {
                st3 = 1;
                TestMain.Self.UpdateTxtProgressInfo("Status 3: " + uut_cmd.m_status3, 1);
                AddtoDataLog(uut_cmd.m_status3);
            }
            else
            {
                st3 = 0;
                TestMain.Self.UpdateTxtProgressInfo("Status 3: " + uut_cmd.m_status3, 0);
                AddtoDataLog(uut_cmd.m_status3);
            }
            if (uut_cmd.m_status4 == "0x18" || uut_cmd.m_status4 == "0x8" || uut_cmd.m_status4 == "0x00")
            {
                st4 = 1;
                TestMain.Self.UpdateTxtProgressInfo("Status 4: " + uut_cmd.m_status4, 1);
                AddtoDataLog(uut_cmd.m_status4);
            }
            else
            {
                st4 = 0;
                TestMain.Self.UpdateTxtProgressInfo("Status 4: " + uut_cmd.m_status4, 0);
                AddtoDataLog(uut_cmd.m_status4);
            }


            double voltagedelta = uut_cmd.m_CMax_volt - uut_cmd.m_CMin_volt;
            if ((voltagedelta) < m_Cell_MaxMin_delta)
            {
                cell_delta = 1;
                TestMain.Self.UpdateTxtProgressInfo("Cell Voltage Delta: " + voltagedelta.ToString("0.00") + " mV", 1);
                //SetPassFail(1);
                AddtoDataLog(voltagedelta.ToString("0.00") + " mV");
            }
            else
            {
                cell_delta = 0;
                TestMain.Self.UpdateTxtProgressInfo("Cell Voltage Delta " + m_Cell_MaxMin_delta + "mV: " + voltagedelta.ToString("0.00") + " mV", 0);
                //SetPassFail(0);
                AddtoDataLog(voltagedelta.ToString("0.00") + " mV");
            }

            double capacity_percent = remaining_capacity / full_capacity;
            if (capacity_percent < m_Max_charge_percentage)
            {
                charge_percent = 1;
                TestMain.Self.UpdateTxtProgressInfo("Charge Percentage " + capacity_percent.ToString("0.00"), 1);
                AddtoDataLog(capacity_percent.ToString("0.00"));
            }
            else
            {
                charge_percent = 0;
                TestMain.Self.UpdateTxtProgressInfo("Charge Percentage " + capacity_percent.ToString("0.00"), 0);
                AddtoDataLog(capacity_percent.ToString("0.00"));
            }


            AddtoDataLog(full_capacity.ToString("0.00") + " mAh");
            AddtoDataLog(design_capacity.ToString("0.00") + " mAh");
            AddtoDataLog(remaining_capacity.ToString("0.00") + " mAh");



            Console.WriteLine("Latch: " + TestMain.is_latch_on);

            // instantaneous mA
            inst_ma = 0;
            for (int i=0; i<5; i++)
            {
                if (uut_cmd.m_instant_current == 0)
                {
                    inst_ma = 1;
                    TestMain.Self.UpdateTxtProgressInfo("Instant mA: " + uut_cmd.m_instant_current, 1);
                    AddtoDataLog(uut_cmd.m_instant_current.ToString("0.00") + " mAh");
                    break;
                }
                else if (fuga_pf == 1 && pack_pf == 1 && st1 == 1 && st2 == 1 && st3 == 1 && st4 == 1 && cell_delta == 1 && charge_percent == 1)
                {
                    instant_current = uut_cmd.m_instant_current;
                    TestMain.Self.UpdateTxtProgressInfo("Instantaneous Current: " + instant_current.ToString("0.00") + " mA", 2);
                    System.Threading.Thread.Sleep(3000);
                    uut_cmd.CANVerification();
                    m_Datalog.StoreCANMessage(uut_cmd.m_final_test_output);
                }
                else
                {
                    inst_ma = 0;
                    TestMain.Self.UpdateTxtProgressInfo("Instant mA: " + uut_cmd.m_instant_current, 0);
                    AddtoDataLog(uut_cmd.m_instant_current.ToString("0.00") + " mA");
                    break;
                }
            }

            //if (inst_ma == 0)
            //{

            //}
            


            //bool latchsw = TestMain.isLatchSwOn();
            if (TestMain.Self.get_testmode() == "Final")
            {
                if (TestMain.is_latch_on)
                {
                    sw = 1;
                    TestMain.Self.UpdateTxtProgressInfo("Latch Switch Status: ON", 1);
                    AddtoDataLog("1");
                }
                else
                {
                    sw = 0;
                    TestMain.Self.UpdateTxtProgressInfo("Latch Switch Status: OFF", 0);
                    AddtoDataLog("0");
                }

                if (uut_cmd.m_load_check_serialnum == "Success")
                {
                    srl_read = 1;
                    TestMain.Self.UpdateTxtProgressInfo("Load and Read Serial Number: Successful", 1);
                    AddtoDataLog("Success");
                }
                else
                {
                    srl_read = 0;
                    TestMain.Self.UpdateTxtProgressInfo("Load and Read Serial Number: Failure ", 0);
                    AddtoDataLog("Fail");
                }
            }
            else
            {
                sw = 1;
                TestMain.Self.UpdateTxtProgressInfo("Latch Switch Status: N/A", 1);
                AddtoDataLog("NA");

                srl_read = 1;
                TestMain.Self.UpdateTxtProgressInfo("Load and Read Serial Number: N/A", 1);
                AddtoDataLog("NA");
            }

            if (st1 == 1 && st2 == 1 && st3 == 1 && st4 == 1 && cell_delta == 1 && fuga_pf == 1 && pack_pf == 1 && cell_delta == 1 && sw == 1 && inst_ma == 1 && srl_read == 1 && charge_percent == 1)
            {
                SetPassFail(1);
            }
            else
            {
                SetPassFail(0);
            }
            Application.DoEvents();
        }
    }
}
