﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using NationalInstruments.VisaNS;

namespace HOB_CM_Test
{
    class KeySiE36103A : VisaDevice
    {
        ConfigData m_ConfigData = new ConfigData();

        public KeySiE36103A()
        {
            m_ConfigData.LoadConfigFile();

            SetVisaAddr(m_ConfigData.KEYSI_E36103A_VISA_addr);
        }

        public void Supply_Out_Volt(string volt)
        {
            string temp = "SOUR:VOLT:LEV:IMM:AMPL " + volt;
            SelectInstrument();
            Write_Data_Instrument(temp);
        }

        public void Supply_Out_Current(string current)
        {
            string temp = "SOUR:CURR:LEV:IMM:AMPL " + current;
            SelectInstrument();
            Write_Data_Instrument(temp);
        }

        public double Meas_Supply_Current()
        {
            SelectInstrument();
            Write_Data_Instrument("MEAS:CURR:DC?");
            string readback = Read_Instrument_Data();
            readback = readback.Replace("A\n", string.Empty);
            return double.Parse(readback);
        }

        public double Meas_Supply_Voltage()
        {
            SelectInstrument();
            Write_Data_Instrument("MEAS:VOLT:DC?");
            string readback = Read_Instrument_Data();
            readback = readback.Replace("V\n", string.Empty);
            return double.Parse(readback);
        }

        public void Supply_Output_ON()
        {
            SelectInstrument();
            Write_Data_Instrument("OUTP:STAT ON");
        }

        // Turn OFF the Power Supply Output
        public void Supply_Output_OFF()
        {
            SelectInstrument();
            Write_Data_Instrument("OUTP:STAT OFF");
        }

        // Power Supply Voltage Range High
        public void Supply_Range_High()
        {
            SelectInstrument();
            Write_Data_Instrument("OUTP:RANG 32V");
        }

        // Power Supply Voltage Range Low
        public void Supply_Range_Low()
        {
            SelectInstrument();
            Write_Data_Instrument("OUTP:RANG 16V");
        }

        public void Supply_Remote()
        {
            SelectInstrument();
            Write_Data_Instrument("SYST:REM");
        }

        public void Supply_Local()
        {
            SelectInstrument();
            Write_Data_Instrument("SYST:LOC");
        }
    }
}
