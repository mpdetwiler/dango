﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MccDaq;

namespace HOB_CM_Test
{
    class McDaqUSB231 : McDaqIF
    {
        public McDaqUSB231()
        {
            try
            {
                BoardNum = 0;
                ULstat = MccDaq.MccService.ErrHandling(MccDaq.ErrorReporting.PrintAll, MccDaq.ErrorHandling.StopAll);

                DaqBoard = new MccDaq.MccBoard(BoardNum);

                ULstat = DaqBoard.DConfigPort(MccDaq.DigitalPortType.AuxPort, MccDaq.DigitalPortDirection.DigitalOut);
            }
            catch
            {
                MessageBox.Show("Unable to initilize MccDaq Module.");
            }
        }

        public override double GetAChanVoltage(int chan) 
        {
            DaqBoard.AIn(chan, MccDaq.Range.Bip10Volts, out Datain);
            DaqBoard.ToEngUnits(MccDaq.Range.Bip10Volts, Datain, out enguint);
            return (double)enguint;
        }

        public override void SetChanOn (ushort chan)
        {
            int dchan = 0x1 << chan;

            ULstat = DaqBoard.DOut(MccDaq.DigitalPortType.AuxPort, (ushort)dchan);
            System.Threading.Thread.Sleep(500);
        }

        public override void SetAllChanOff()
        {
            ULstat = DaqBoard.DOut(MccDaq.DigitalPortType.AuxPort, 0);
            System.Threading.Thread.Sleep(500);
        }

        public override double SystemVoltage()
        {
            return 4.985;
        }

        public override double DACInputRes()
        {
            return 1375.0;
        }

        public override void EnableGNDResetVolt(int val)
        {
            if (val == 1)
                SetChanOn(0);
            else
                SetAllChanOff();
        }

        public override void EnablePWRResetVolt(int val)
        {
            if (val == 1)
                SetChanOn(1);
            else
                SetAllChanOff();
        }

        public override double GetResCorrectionFactor(double val)
        {
            return 0.0002 * val * val + 0.0338 * val - 0.1553;
        }

        public override double GetThermistorVal()
        {
            return GetResOnChan(1, false);
        }

        public override double GetResistorIDVal()
        {
            return GetResOnChan(0, false);
        }
    }
    
}
