﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MccDaq;

namespace HOB_CM_Test
{
    class McDaqAcmeAero : McDaqIF
    {

    }
}
