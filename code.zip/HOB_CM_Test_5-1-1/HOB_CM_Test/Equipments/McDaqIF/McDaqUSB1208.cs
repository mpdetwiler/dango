﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MccDaq;
using System.Windows.Forms;

namespace HOB_CM_Test
{
    class McDaqUSB1208 : McDaqIF
    {
        public DaqDeviceDescriptor[] inventory;
        public MccDaq.DigitalLogicState[] MyBitVal;

        public McDaqUSB1208()
        {
            try
            {
                BoardNum = 0;
                ULstat = MccService.ErrHandling(ErrorReporting.PrintAll, ErrorHandling.StopAll);
                inventory = MccDaq.DaqDeviceManager.GetDaqDeviceInventory(DaqDeviceInterface.Any);
                int numDevDiscovered = inventory.Length;
                if (numDevDiscovered > 0)
                {
                    for (Int16 BoardNum = 0; BoardNum < numDevDiscovered; BoardNum++)
                    {
                        DaqBoard = new MccBoard(BoardNum);

                        if (DaqBoard.BoardName.Contains("231") || DaqBoard.BoardName.Contains("234"))
                        {
                            DaqBoard.FlashLED();
                        }
                        else if (DaqBoard.BoardName.Contains("1208"))
                        {
                            //DaqBoard.FlashLED();
                            ULstat = DaqBoard.DConfigPort(MccDaq.DigitalPortType.FirstPortA, MccDaq.DigitalPortDirection.DigitalOut);
                            ULstat = DaqBoard.DOut(MccDaq.DigitalPortType.FirstPortA, 0);                    //turn all bits back off.
                            ULstat = DaqBoard.DConfigPort(MccDaq.DigitalPortType.FirstPortB, MccDaq.DigitalPortDirection.DigitalIn);
                        }
                    }

                    
                    SetPortAChan(7, 1);
                    System.Threading.Thread.Sleep(200);
                    SetPortAChan(7, 0);
                    System.Threading.Thread.Sleep(200);
                    SetPortAChan(7, 1);
                    System.Threading.Thread.Sleep(200);
                    SetPortAChan(7, 0);

                    SetAllChanOff();

                    DaqBoard.AOut(0, MccDaq.Range.Bip5Volts, 0);     // Set Anlog Output 0 pin to 1.07 volts (for battery address)
                }
            }
            catch
            {
                MessageBox.Show("Unable to initilize MccDaq Module.");
            }
        }

        public ushort ReadPortAData()
        {
            ushort data;
            ULstat = DaqBoard.DIn(MccDaq.DigitalPortType.FirstPortA, out data);
            return data;
        }

        public ushort ReadPortBData()
        {
            ushort data;
            ULstat = DaqBoard.DIn(MccDaq.DigitalPortType.FirstPortB, out data);
            return data;
        }

        public void SetPortAChan(int chan, int val)
        {
            int DIO_val = ReadPortAData();
            int dchan = 0x1 << chan;
            if (val == 1)
            {
                DIO_val |= dchan;
            }
            else
            {
                dchan = ~dchan;
                DIO_val &= dchan;
            }

            ULstat = DaqBoard.DOut(MccDaq.DigitalPortType.FirstPortA, (ushort)DIO_val);
            System.Threading.Thread.Sleep(1000);
        }

        public override void SetAllChanOff()
        {
            ULstat = DaqBoard.DOut(MccDaq.DigitalPortType.FirstPortA, (ushort)0x00);
        }

        public void errhandler(MccDaq.ErrorInfo ULStat)
        {
            //Generic UL error handler
            MessageBox.Show(ULStat.Message, "Universal Library Error ", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}
