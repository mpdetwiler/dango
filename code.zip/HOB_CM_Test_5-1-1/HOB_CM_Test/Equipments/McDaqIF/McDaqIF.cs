﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MccDaq;

namespace HOB_CM_Test
{
    class McDaqIF
    {
        public MccDaq.MccBoard DaqBoard;
        public MccDaq.ErrorInfo ULstat;

        public int BoardNum;
        public ushort Datain;
        public float enguint;
        public int m_DIO_val = 0x00;

        public virtual void SetPortAChan(ushort chan, int val) { }
        public virtual void SetPortBChan(ushort chan, int val) { }


        public virtual double GetAChanVoltage(int chan) { return 0.0; }
        public virtual void SetChanOn(ushort chan) { }
        public virtual void SetChanOff(ushort chan) { }
        public virtual void SetAllChanOff() { }
        public virtual double SystemVoltage() { return 0.0; }
        public virtual double DACInputRes() { return 0.0; }
        public virtual void EnableGNDResetVolt(int val) { }
        public virtual void EnablePWRResetVolt(int val) { }
        public virtual double GetResCorrectionFactor(double val) { return 0; }
        public virtual void TurnOnInfiPeriphBatt1M() {}
        public virtual void TurnOnInfiPeriphBatt2M() { }
        public virtual void TurnOffInfiPeriphAllM() { }
        public virtual double GetThermistorVal() { return 0.0; }
        public virtual double GetResistorIDVal() { return 0.0; }
        public virtual void SetPowerConnection(int val) { }      //0 - disconnect; 1 - connect
        public virtual void SetLoadConnection(int val) { }       //0 - disconnect; 1 - connect

        //For Acme Aero
        public virtual void DisConnectAllRly() { }
        public virtual void SetThrmRly(int val) { }             // 0 - disconnect; 1 - connect
        public virtual void SetPackOCVRly(int val) { }             // 0 - disconnect; 1 - connect
        public virtual void SetMidTapOCVRly(int val) { }             // 0 - disconnect; 1 - connect

       
        public virtual double GetResOnChan(int chan, bool correction = true) 
        {
            double d_res = 10.0;  //Kohm
            double d_resistance;
            double f_voltage;
            double d_sysVolt = SystemVoltage();
            f_voltage = GetAChanVoltage(chan);

            d_resistance = (f_voltage * d_res) / (d_sysVolt - f_voltage);
            if (correction == true)
            {
                d_resistance = Math.Abs((DACInputRes() * d_resistance) / (DACInputRes() - d_resistance));
                d_resistance = d_resistance + GetResCorrectionFactor(d_resistance);
            }

            return d_resistance;
        }
    }
}
