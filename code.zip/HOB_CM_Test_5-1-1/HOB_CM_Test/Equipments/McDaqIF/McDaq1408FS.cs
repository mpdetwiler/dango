﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MccDaq;

namespace HOB_CM_Test
{
    class McDaq1408FS : McDaqIF
    {
        public McDaq1408FS()
        {
            try
            {
                BoardNum = 0;
                ULstat = MccDaq.MccService.ErrHandling(MccDaq.ErrorReporting.PrintAll, MccDaq.ErrorHandling.StopAll);

                DaqBoard = new MccDaq.MccBoard(BoardNum);

                ULstat = DaqBoard.DConfigPort(MccDaq.DigitalPortType.FirstPortA, MccDaq.DigitalPortDirection.DigitalOut);
            }
            catch
            {
                MessageBox.Show("Unable to initilize MccDaq Module.");
            }
        }

        public override double GetAChanVoltage(int chan)
        {
            DaqBoard.AIn(chan, MccDaq.Range.Bip20Volts, out Datain);
            DaqBoard.ToEngUnits(MccDaq.Range.Bip20Volts, Datain, out enguint);
            return (double)enguint;
        }
        
        public override void SetChanOn(ushort chan)
        {
            int dchan = 0x1 << chan;
            m_DIO_val |= dchan;

            ULstat = DaqBoard.DOut(MccDaq.DigitalPortType.FirstPortA, (ushort)dchan);
            System.Threading.Thread.Sleep(500);
        }

        public override void SetChanOff(ushort chan)
        {
            int dchan = 0x1 << chan;
            dchan = ~dchan;
            m_DIO_val &= dchan;

            ULstat = DaqBoard.DOut(MccDaq.DigitalPortType.FirstPortA, (ushort)m_DIO_val);
            System.Threading.Thread.Sleep(500);
        }

        public override void SetAllChanOff()
        {
            ULstat = DaqBoard.DOut(MccDaq.DigitalPortType.FirstPortA, 0);
            System.Threading.Thread.Sleep(500);
        }

    }
}
