﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HOB_CM_Test
{
    class SerComApp : SerialCom
    {
        int m_total_byte, m_timout_limit;

        public SerComApp()
        {
            m_total_byte = 0;
            m_timout_limit = 10000;
        }
        
        public void ReadRxBufferToThreshold(int threshold)
        {
            for (int idx = 0; idx < 128; idx++)
            {
                m_char_buffer_final[idx] = '0';
            }
            m_total_byte = 0;
            int num_byte;

            int id_idx = 0;
            int time_out = 0;
            while (true)
            {
                time_out++;
                if (time_out > m_timout_limit)
                {
                    MessageBox.Show("Timeout at SerialCom::ReadRxBufferToThreshold()");
                    break;
                }

                num_byte = serialport.BytesToRead;
                if (num_byte == 0)
                    continue;

                m_total_byte = m_total_byte + num_byte;

                serialport.Read(m_byte_buffer_temp, 0, num_byte);
                for (int idx = 0; idx < num_byte; idx++)
                {
                    m_byte_buffer_final[id_idx] = m_byte_buffer_temp[idx];
                    id_idx++;
                }

                if (m_total_byte >= threshold)
                {
                    break;
                }

                System.Threading.Thread.Sleep(50);
            }
        }

        public void ReadRxBufferUntilNewline()
        {
            for (int idx = 0; idx < 128; idx++)
            {
                m_char_buffer_final[idx] = '0';
            }
            int num_byte;

            int id_idx = 0;
            int time_out = 0;
            while (true)
            {
                time_out++;
                if (time_out > 10000)
                {
                    MessageBox.Show("Timeout at SerialCom::ReadRxBufferUntilNewline()");
                    break;
                }

                num_byte = serialport.BytesToRead;
                if (num_byte == 0)
                    continue;

                serialport.Read(m_char_buffer_temp, 0, num_byte);
                for (int idx = 0; idx < num_byte; idx++)
                {
                    m_char_buffer_final[id_idx] = m_char_buffer_temp[idx];
                    id_idx++;
                }

                if (m_char_buffer_temp[num_byte - 1] == '\n')
                    break;

                System.Threading.Thread.Sleep(10);
            }
        }
    }
}
