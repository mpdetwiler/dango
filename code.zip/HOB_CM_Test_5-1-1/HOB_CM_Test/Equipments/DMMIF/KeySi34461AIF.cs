﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HOB_CM_Test
{
    class KeySi34461AIF : DmmBaseIF
    {
        KeySi34461A m_Dmm = new KeySi34461A();

        public override string GetInstrumentID()
        {
            return m_Dmm.GetInstrumentID();
        }
        
        public override double Get_Meas_Volt() 
        {
            return m_Dmm.Get_Meas_Volt();
        }
        public override void Sample_Count(int count) 
        {
            m_Dmm.Sample_Count(count);
        }

        public override void Set_DC_NPLC(double d_plc) 
        {
            m_Dmm.Set_DC_NPLC(d_plc);
        }

        public override void Config_DC_Range(int range) 
        {
            m_Dmm.Config_DC_Range(range);
        }

        public override void Turn_OnOff_Stat(int stat) 
        {
            m_Dmm.Turn_OnOff_Stat(stat);
        }

        public override void Init_Stat() 
        {
            m_Dmm.Init_Stat();
        }

        public override void WAIT() 
        {
            m_Dmm.WAIT();
        }

        public override string Get_Stat_Data() 
        {
            return m_Dmm.Get_Stat_Data();
        }

        public override double Get_Stat_Max() 
        {
            return m_Dmm.Get_Stat_Max();        
        }

        public override double Get_Stat_Min() 
        {
            return m_Dmm.Get_Stat_Min();        
        }

        public override double Get_PLC_Time_Resolution(double plc) 
        {
            return m_Dmm.Get_PLC_Time_Resolution(plc);        
        }

    }
}
