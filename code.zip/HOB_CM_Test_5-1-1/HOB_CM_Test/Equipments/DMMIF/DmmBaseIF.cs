﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HOB_CM_Test
{
    class DmmBaseIF
    {
        public virtual string GetInstrumentID() { return ""; }
        public virtual double Get_Meas_Volt() { return 0.0; }
        public virtual void Sample_Count(int count) { }
        public virtual void Set_DC_NPLC(double d_plc) { }
        public virtual void Config_DC_Range(int range) { }
        public virtual void Turn_OnOff_Stat(int stat) { }
        public virtual void Init_Stat() { }
        public virtual void WAIT() { }
        public virtual string Get_Stat_Data() { return ""; }
        public virtual double Get_Stat_Max() { return 0; }
        public virtual double Get_Stat_Min() { return 0; }
        public virtual double Get_PLC_Time_Resolution(double plc) { return 0; }
    }
}
