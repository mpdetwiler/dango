﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using NationalInstruments.VisaNS;

namespace HOB_CM_Test
{
    class VisaDevice : Conversion
    {
        private string strVisaRsrc = null;
        private MessageBasedSession mbSession;

        public void SelectInstrument()
        {
            try
            {
                mbSession = (MessageBasedSession)ResourceManager.GetLocalManager().Open(strVisaRsrc);
            }
            catch (InvalidCastException)
            {
                MessageBox.Show("Resource Selected must be a message-based session");
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
        }

        public string Read_Instrument_Data()
        {
            string strRead = null;
            try
            {
                strRead = mbSession.ReadString();              // Read String from Visa resource
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
            return strRead;
        }

        // Routine Writes String Data to the Instrument
        //
        public void Write_Data_Instrument(string Data)
        {
            string strWrite = Data;
            try
            {
                mbSession.Write(strWrite);
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
        }

        public void SetVisaAddr(string str)
        {
            strVisaRsrc = null;
            strVisaRsrc = str;
        }

        public string GetInstrumentID()
        {
            SelectInstrument();
            Write_Data_Instrument("*IDN?");
            return Read_Instrument_Data();
        }

    }
}
