﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HOB_CM_Test
{
    class PSBaseIF
    {
        public McDaqIF m_McDaqIF;

        public virtual void DisplayLimitToLstBox() { }
        public virtual void Supply_Remote(){}
        public virtual void Supply_Range_High(){}
        public virtual void Supply_Range_Low() { }
        public virtual string GetInstrumentID(){return "";}
        public virtual void Supply_Output_ON() { }
        public virtual void Supply_Output_OFF() { }
        public virtual double Meas_Supply_Voltage() { return 0; }
        public virtual double Meas_Supply_Current() { return 0; }
        public virtual void Supply_Out_Volt(string volt) { }
        public virtual void Supply_Out_Current(string current) { }

        //Delay Parameters for PCB Board Testing
        public virtual int PWRPCMOverVoltageProtectionDelay() { return 1; }
        public virtual int PWRPCMOverVoltageReleaseDelay() { return 1; }
        public virtual int PWRPCMUnderVoltageProtectionDelay() { return 1; }
        public virtual int PWRPCMUnderVoltageReleaseDelay() { return 1; }
        public virtual int PWRPCMOCDDelay() { return 1; }

        //Delay Parameters for Pack Testing
        public virtual int PWRPackTestChargeAcceptanceDelay() { return 700; }

        public virtual void SetMcDaqIF(McDaqIF daq)
        {
            m_McDaqIF = daq;
        }

    }
}










