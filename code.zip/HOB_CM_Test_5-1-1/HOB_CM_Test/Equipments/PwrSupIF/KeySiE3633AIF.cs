﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HOB_CM_Test
{
    class KeySiE3633AIF : PSBaseIF
    {
        KeySiE3633A m_PS;

        public KeySiE3633AIF()
        {
            m_PS = new KeySiE3633A();
        }

        public override void Supply_Remote()
        {
            m_PS.Supply_Remote();
        }

        public override void Supply_Range_High()
        {
            m_PS.Supply_Range_High();
        }

        public override void Supply_Range_Low()
        {
            m_PS.Supply_Range_Low();
        }

        public override string GetInstrumentID()
        {
            return m_PS.GetInstrumentID();
        }

        public override void Supply_Output_ON()
        {
            m_PS.Supply_Output_ON();
            m_McDaqIF.SetPowerConnection(1);
        }

        public override void Supply_Output_OFF()
        {
            m_McDaqIF.SetPowerConnection(0);
            m_PS.Supply_Output_OFF();
        }

        public override double Meas_Supply_Voltage()
        {
            return m_PS.Meas_Supply_Voltage();
        }

        public override double Meas_Supply_Current()
        {
            return m_PS.Meas_Supply_Current();
        }

        public override void Supply_Out_Volt(string volt)
        {
            m_PS.Supply_Out_Volt(volt);
        }

        public override void Supply_Out_Current(string current)
        {
            m_PS.Supply_Out_Current(current);
        }
    
    }
}
