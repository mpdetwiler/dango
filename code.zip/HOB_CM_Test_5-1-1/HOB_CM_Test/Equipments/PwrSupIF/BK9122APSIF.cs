﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HOB_CM_Test
{
    class BK9122APSIF : PSBaseIF 
    {
        BK9122APS m_PS;

        public BK9122APSIF()
        {
            m_PS = new BK9122APS();
        }

        public override void Supply_Remote()
        {
            m_PS.Supply_Remote();
        }

        public override void Supply_Range_High()
        {
            m_PS.Supply_Range_High();
        }

        public override string GetInstrumentID()
        {
            return m_PS.GetInstrumentID();
        }

        public override void Supply_Output_ON()
        {
            m_PS.Supply_Output_ON();
        }

        public override void Supply_Output_OFF()
        {
            m_PS.Supply_Output_OFF();
        }

        public override double Meas_Supply_Voltage()
        {
            return m_PS.Meas_Supply_Voltage();
        }

        public override double Meas_Supply_Current()
        {
            return m_PS.Meas_Supply_Current();
        }

        public override void Supply_Out_Volt(string volt)
        {
            m_PS.Supply_Out_Volt(volt);
        }

        public override void Supply_Out_Current(string current)
        {
            m_PS.Supply_Out_Current(current);
        }
    }
}
