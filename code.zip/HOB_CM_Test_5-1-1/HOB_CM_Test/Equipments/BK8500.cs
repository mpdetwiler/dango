﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HOB_CM_Test
{
    class BK8500 : SerComApp
    {
        Byte[] ma_genericPackCmd = new Byte[26] { 0xAA, 0x00, 0x20, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xCB };
        public double m_DC_Voltage_val, m_DC_Curr_val;
        int m_BKopen, m_Rxthreshold;

        static private Object thisLock = new Object();
        int m_general_delay;

        ConfigData m_configData;

        public BK8500()
        {
            m_BKopen = 0;
            m_general_delay = 200;
            m_Rxthreshold = 26;

            m_configData = new ConfigData();
            m_configData.LoadConfigFile();

            if (OpenPort(m_configData.BK_comport) == -1)
                return;

            InitRemote(1);
            load_off();
        }

        public int IsBKOpen()
        {
            return m_BKopen;
        }

        //Set to remote operation;
        //1 - remote; 0 - front panel
        public void InitRemote(byte remote)
        {
            lock (thisLock)
            {
                ma_genericPackCmd[2] = 0x20;             // Setup Current value Commmand 
                ma_genericPackCmd[3] = remote;           // Lower low Byte
                ma_genericPackCmd[4] = 0x00;
                ma_genericPackCmd[5] = 0x00;
                ma_genericPackCmd[6] = 0x00;             // Upper upper byte

                CalculateChecksum();
                Write(ma_genericPackCmd, 0, 26);

                System.Threading.Thread.Sleep(m_general_delay);
                ReadRxBufferToThreshold(m_Rxthreshold);

                if (m_byte_buffer_final[2] == 18 &&
                     ((m_byte_buffer_final[3] == 128) || (m_byte_buffer_final[3] == 176)))
                    m_BKopen = 1;
                else
                    System.Windows.Forms.MessageBox.Show("BK8500::InitRemote: Unable to communicate with device.");
            }
        }

        public void SetBatteryVoltage(double volt)
        {
            lock (thisLock)
            {
                int voltage = (int)(volt * 1000);
                ma_genericPackCmd[2] = 0x4E;                                           // Setup Current value Commmand 
                ma_genericPackCmd[3] = Convert.ToByte(voltage & 0x000000FF);              // Lower low Byte
                ma_genericPackCmd[4] = Convert.ToByte((voltage & 0x0000FF00) >> 8);
                ma_genericPackCmd[5] = Convert.ToByte((voltage & 0x00FF0000) >> 16);
                ma_genericPackCmd[6] = Convert.ToByte((voltage & 0xFF000000) >> 32);      // Upper upper byte

                CalculateChecksum();
                Write(ma_genericPackCmd, 0, 26);

                System.Threading.Thread.Sleep(m_general_delay);
                ReadRxBufferToThreshold(m_Rxthreshold);

                if (!(m_byte_buffer_final[2] == 18 &&
                        ((m_byte_buffer_final[3] == 128) || (m_byte_buffer_final[3] == 176))))
                    System.Windows.Forms.MessageBox.Show("BK8500::SetBatteryVoltage: Unable to communicate with device.");
            }
        }

        public void read_vol_curr_pwr()
        {
            lock (thisLock)
            {
                ma_genericPackCmd[2] = 0x5F;             // Setup Current value Commmand 
                ma_genericPackCmd[3] = 0x00;             // Lower low Byte
                ma_genericPackCmd[4] = 0x00;
                ma_genericPackCmd[5] = 0x00;
                ma_genericPackCmd[6] = 0x00;             // Upper upper byte

                CalculateChecksum();
                Write(ma_genericPackCmd, 0, 26);

                System.Threading.Thread.Sleep(m_general_delay);
                ReadRxBufferToThreshold(m_Rxthreshold);
            }
        }

        public void get_voltage_curr_data()
        {

            read_vol_curr_pwr();

            byte[] byteReadTest = new byte[4];

            byteReadTest[3] = m_byte_buffer_final[6];
            byteReadTest[2] = m_byte_buffer_final[5];
            byteReadTest[1] = m_byte_buffer_final[4];
            byteReadTest[0] = m_byte_buffer_final[3];

            int aa = byteReadTest[3] << 24;
            int bb = byteReadTest[2] << 16;
            int cc = byteReadTest[1] << 8;
            int dd = byteReadTest[0] << 0;

            int result = 0;
            result = result | aa;
            result = result | bb;
            result = result | cc;
            result = result | dd;

            m_DC_Voltage_val = (double)result / 1000.0;   //result in V

            //get current val
            byteReadTest[3] = m_byte_buffer_final[10];
            byteReadTest[2] = m_byte_buffer_final[9];
            byteReadTest[1] = m_byte_buffer_final[8];
            byteReadTest[0] = m_byte_buffer_final[7];

            aa = byteReadTest[3] << 24;
            bb = byteReadTest[2] << 16;
            cc = byteReadTest[1] << 8;
            dd = byteReadTest[0] << 0;

            result = 0;
            result = result | aa;
            result = result | bb;
            result = result | cc;
            result = result | dd;

            m_DC_Curr_val = (double)result;
            m_DC_Curr_val = m_DC_Curr_val / 10000.0;  //convert result to A
        }

        public double GetMeasVoltage()
        {
            return m_DC_Voltage_val;
        }

        public double GetMeasCurrent()
        {
            return m_DC_Curr_val;
        }


        /**********************************************************************
          * Routine Sets the Operating Mode of the Load
          * By Sending Command 0x21
          * Followed by byte 3:
          *  0 equal Constant Current
          *  1 equal Constant Voltage
          *  2 equal Constant Watt
          *  3 equal Constant Resistance
        * *******************************************************************/
        public void load_on()
        {
            lock (thisLock)
            {
                ma_genericPackCmd[2] = 0x21;             //Send Mode setup Commmand
                ma_genericPackCmd[3] = 01;                           //Turn ON the load
                ma_genericPackCmd[4] = 0x00;
                ma_genericPackCmd[5] = 0x00;
                ma_genericPackCmd[6] = 0x00;

                CalculateChecksum();
                Write(ma_genericPackCmd, 0, 26);

                System.Threading.Thread.Sleep(m_general_delay);
                ReadRxBufferToThreshold(m_Rxthreshold);

                if (!(m_byte_buffer_final[2] == 18 &&
                        ((m_byte_buffer_final[3] == 128) || (m_byte_buffer_final[3] == 176))))
                    System.Windows.Forms.MessageBox.Show("BK8500::load_on(): Unable to communicate with device.");
            }
        }

        public void load_off()
        {
            lock (thisLock)
            {
                ma_genericPackCmd[2] = 0x21;             //Send Mode setup Commmand
                ma_genericPackCmd[3] = 0x00;                         // Turn ON the load
                ma_genericPackCmd[4] = 0x00;
                ma_genericPackCmd[5] = 0x00;
                ma_genericPackCmd[6] = 0x00;

                CalculateChecksum();
                Write(ma_genericPackCmd, 0, 26);

                System.Threading.Thread.Sleep(m_general_delay);
                ReadRxBufferToThreshold(m_Rxthreshold);

                if (!(m_byte_buffer_final[2] == 18 &&
                        ((m_byte_buffer_final[3] == 128) || (m_byte_buffer_final[3] == 176))))
                    System.Windows.Forms.MessageBox.Show("BK8500::load_off(): Unable to communicate with device.");
            }
        }

        public void load_mode(byte mode)
        {
            lock (thisLock)
            {
                ma_genericPackCmd[2] = 0x28;             //Send Mode setup Commmand
                ma_genericPackCmd[3] = mode;             //Set the operating mode
                ma_genericPackCmd[4] = 0x00;
                ma_genericPackCmd[5] = 0x00;
                ma_genericPackCmd[6] = 0x00;

                CalculateChecksum();
                Write(ma_genericPackCmd, 0, 26);

                System.Threading.Thread.Sleep(m_general_delay);
                ReadRxBufferToThreshold(m_Rxthreshold);

                if (!(m_byte_buffer_final[2] == 18 &&
                        ((m_byte_buffer_final[3] == 128) || (m_byte_buffer_final[3] == 176))))
                    System.Windows.Forms.MessageBox.Show("BK8500::load_mode(): Unable to communicate with device.");
            }
        }

        /**********************************************************************
        * Routine Sets the mode to either fix/short/tran/list/battery
        *  0 fix
        *  1 short
        *  2 tran
        *  3 list
        *  4 battery
        * *******************************************************************/
        public void Set_function_mode(byte mode)
        {
            lock (thisLock)
            {

                ma_genericPackCmd[2] = 0x5D;             //Send Mode setup Commmand
                ma_genericPackCmd[3] = mode;             //Set the operating mode
                ma_genericPackCmd[4] = 0x00;
                ma_genericPackCmd[5] = 0x00;
                ma_genericPackCmd[6] = 0x00;

                CalculateChecksum();
                Write(ma_genericPackCmd, 0, 26);

                System.Threading.Thread.Sleep(m_general_delay);
                ReadRxBufferToThreshold(m_Rxthreshold);

                if (!(m_byte_buffer_final[2] == 18 &&
                        ((m_byte_buffer_final[3] == 128) || (m_byte_buffer_final[3] == 176))))
                    System.Windows.Forms.MessageBox.Show("BK8500::Set_function_mode(): Unable to communicate with device.");
            }
        }


        /**********************************************************************
       * Routine Sets the Constant Current Value for the Load
       *  Enter with Current in mA (current)
       * By Sending Command 0x2A
       * Followed by Byte 3,4,5,6:
       *  3 lower low byte of Current
       *  4 lower high byte of Current
       *  5 Upper low byte of current
       *  6 Upper high byte of current
       * *******************************************************************/
        public void set_current(Int64 current)
        {
            lock (thisLock)
            {
                current = current * 10;                                                   // convert to 0.1mA scale

                ma_genericPackCmd[2] = 0x2A;                                                 // Setup Current value Commmand
                ma_genericPackCmd[3] = Convert.ToByte(current & 0x000000FF);                 // Lower low Byte
                ma_genericPackCmd[4] = Convert.ToByte((current & 0x0000FF00) >> 8);
                ma_genericPackCmd[5] = Convert.ToByte((current & 0x00FF0000) >> 16);
                ma_genericPackCmd[6] = Convert.ToByte((current & 0xFF000000) >> 32);         // Upper upper byte

                CalculateChecksum();
                Write(ma_genericPackCmd, 0, 26);

                System.Threading.Thread.Sleep(m_general_delay);
                ReadRxBufferToThreshold(m_Rxthreshold);

                if (!(m_byte_buffer_final[2] == 18 &&
                        ((m_byte_buffer_final[3] == 128) || (m_byte_buffer_final[3] == 176))))
                    System.Windows.Forms.MessageBox.Show("BK8500::set_current(): Unable to communicate with device.");
            }
        }

        public void set_Rload(Int64 Rload)
        {
            lock (thisLock)
            {
                Rload = Rload * 1000;                                                  // convert to 0.1mA scale

                ma_genericPackCmd[2] = 0x30;                                               // Setup Current value Commmand
                ma_genericPackCmd[3] = Convert.ToByte(Rload & 0x000000FF);                 // Lower low Byte
                ma_genericPackCmd[4] = Convert.ToByte((Rload & 0x0000FF00) >> 8);
                ma_genericPackCmd[5] = Convert.ToByte((Rload & 0x00FF0000) >> 16);
                ma_genericPackCmd[6] = Convert.ToByte((Rload & 0xFF000000) >> 32);

                CalculateChecksum();
                serialport.Write(ma_genericPackCmd, 0, 26);

                System.Threading.Thread.Sleep(m_general_delay);
                ReadRxBufferToThreshold(m_Rxthreshold);

                if (!(m_byte_buffer_final[2] == 18 &&
                        ((m_byte_buffer_final[3] == 128) || (m_byte_buffer_final[3] == 176))))
                    System.Windows.Forms.MessageBox.Show("BK8500::set_Rload(): Unable to communicate with device.");
            }
        }

        public void set_trans_load(int load_on_time1, int load_on_time2, int load_current1, int load_current2)
        {
            lock (thisLock)
            {
                load_current1 = load_current1 * 10;
                ma_genericPackCmd[2] = 0x32;
                //set load current during on time.
                ma_genericPackCmd[3] = Convert.ToByte(load_current1 & 0x000000FF);                 // Lower low Byte
                ma_genericPackCmd[4] = Convert.ToByte((load_current1 & 0x0000FF00) >> 8);
                ma_genericPackCmd[5] = Convert.ToByte((load_current1 & 0x00FF0000) >> 16);
                ma_genericPackCmd[6] = Convert.ToByte((load_current1 & 0xFF000000) >> 32);

                //set on time duration for time1
                load_on_time1 = load_on_time1 * 10;
                ma_genericPackCmd[7] = Convert.ToByte(load_on_time1 & 0x000000FF);                 // Lower low Byte
                ma_genericPackCmd[8] = Convert.ToByte((load_on_time1 & 0x0000FF00) >> 8);

                //set load current during the second phase.  Assuming 0.
                load_current2 = load_current2 * 10;
                ma_genericPackCmd[9] = Convert.ToByte(load_current2 & 0x000000FF);                  // Lower low Byte
                ma_genericPackCmd[10] = Convert.ToByte((load_current2 & 0x0000FF00) >> 8);
                ma_genericPackCmd[11] = Convert.ToByte((load_current2 & 0x00FF0000) >> 16);
                ma_genericPackCmd[12] = Convert.ToByte((load_current2 & 0xFF000000) >> 32);

                //set on time duration for time2
                load_on_time2 = load_on_time2 * 10;
                ma_genericPackCmd[13] = Convert.ToByte(load_on_time2 & 0x000000FF);                 // Lower low Byte
                ma_genericPackCmd[14] = Convert.ToByte((load_on_time2 & 0x0000FF00) >> 8);

                //set to continuous mode
                ma_genericPackCmd[15] = 0x00;

                CalculateChecksum();
                Write(ma_genericPackCmd, 0, 26);

                System.Threading.Thread.Sleep(m_general_delay);
                ReadRxBufferToThreshold(m_Rxthreshold);

                if (!(m_byte_buffer_final[2] == 18 &&
                        ((m_byte_buffer_final[3] == 128) || (m_byte_buffer_final[3] == 176))))
                    System.Windows.Forms.MessageBox.Show("BK8500::set_trans_load(): Unable to communicate with device.");
            }
        }


        /**********************************************************************
          * Routine Calculate Cecksum vale by adding
          * Location [0] --- Loaction [24]
          * Checksum result is put in Location [25]
          * *******************************************************************/
        private string CalculateChecksum()
        {
            lock (thisLock)
            {
                int checksum = 0;
                int chdata = 0;
                int i = 0;

                for (i = 0; i < 25; i++)
                {
                    chdata = ma_genericPackCmd[i];
                    checksum += chdata;
                }

                checksum &= 0xff;
                ma_genericPackCmd[25] = (byte)checksum;                // Save Checksum in the array to transmit

                return checksum.ToString("X2");
            }
        }
    }
}
