﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HOB_CM_Test
{
    class STLinkCmd
    {
        SysCmd m_sysCmd = new SysCmd();

        public void ResetDevice()
        {
            m_sysCmd.RunCmd("ST-LINK_CLI.exe", "-Rst");
        }

        public void FullChipErase()
        {
            m_sysCmd.RunCmd("ST-LINK_CLI.exe", "-ME");
        }

        public void ProgramDevice(string file_path)
        {
            string argument = "-P " + file_path + " -V " + "after_programming -Run";
            m_sysCmd.RunCmd("ST-LINK_CLI.exe", argument);
        }

        public bool VerifyErase()
        {
            return m_sysCmd.ms_cmd_output.Contains("Flash memory erased.");
        }

        public bool VerifyProgrammed()
        {
            return m_sysCmd.ms_cmd_output.Contains("Verification...OK");

        }

        public bool VerifyProgramReset()
        {
            return m_sysCmd.ms_cmd_output.Contains("MCU Reset.");
        }

        public bool VerifyApplicationProgram()
        {
            return m_sysCmd.ms_cmd_output.Contains("SUCCESS!.");
        }
    }
}
