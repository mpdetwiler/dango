﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace HOB_CM_Test
{
    class UUTCommand
    {
        STLinkCmd st_cmd = new STLinkCmd();
        SysCmd sys_cmd = new SysCmd();
        ConfigData config = new ConfigData();
        TestDataLog m_Datalog = new TestDataLog();

        public double m_fuga_temp = -1, m_pack_temp = -1, m_remaining_capacity = -1, m_full_capacity = -1, 
            m_design_capacity = -1, m_instant_current = -1;
        public string m_status1 = "Err", m_status2 = "Err", m_status3 = "Err", m_status4 = "Err", m_load_check_serialnum;
        public string m_final_test_output;
        public double m_CMax_volt = -1, m_CMin_volt = -1;


        public UUTCommand()
        {
            config.LoadProgramFile(config.load_program);
        }

        public int ProgramBoard()
        {
            st_cmd.ProgramDevice(config.test_code);
            if (st_cmd.VerifyProgrammed() == true)
                return 1;
            else
                return 0;
        }

        public int CANVerification()
        {
            m_fuga_temp = -1;
            m_pack_temp = -1;
            m_remaining_capacity = -1;
            m_full_capacity = -1;
            m_design_capacity = -1;
            m_instant_current = -1;
            m_status1 = "Err";
            m_status2 = "Err";
            m_status3 = "Err";
            m_status4 = "Err";
            m_CMax_volt = -1;
            m_CMin_volt = -1;
            m_load_check_serialnum = "Err";
            
            
            //sys_cmd.RunCmdLineTimeout("C:\\AeryonSoftware\\can_test_supvis_single_fixed.exe",  " -n can_test_supvis_battery_measurements", 5000);
  

            sys_cmd.RunCmd("C:\\OTE\\can_protocol_inspect_5_1_1\\can_protocol_inspect.exe", " -n sys -C 10");
            Thread.Sleep(500);

            sys_cmd.RunCmd("C:\\OTE\\can_protocol_inspect_5_1_1\\can_protocol_inspect.exe", " -n sys -R 10");
            Thread.Sleep(500);

            sys_cmd.RunCmd("C:\\OTE\\can_protocol_inspect_5_1_1\\can_protocol_inspect.exe", " -n sys -b 10");
            Thread.Sleep(500);

            string output;
            output = sys_cmd.GetOutputString();
            System.Console.WriteLine("!!!!!!!!!!!!!!!!!!!!!!OUTPUT!!!!!!!!!!!!!!!!!!!");
            System.Console.WriteLine(output);
            m_final_test_output = output;
//            m_Datalog.StoreCANMessage(output);

            //fuel gauge temperature
            try
            {
                //remaining capacity
                int first = output.IndexOf("remaining capacity mAh:") + "remaining capacity mAh:".Length;
                int last = output.LastIndexOf("instantaneous current mA:");
                string str2 = output.Substring(first, last - first);
                System.Console.WriteLine(str2);

                str2 = str2.Replace("\r\n", "").Replace("\r", "").Replace("\n", "");
                str2 = str2.Replace(":", "");
                System.Console.WriteLine(str2);

                m_remaining_capacity = double.Parse(str2, System.Globalization.CultureInfo.InvariantCulture);
                System.Console.WriteLine(m_remaining_capacity);

                //fuel guage temperature
                first = output.IndexOf("fuel gauge temp C:") + "pack ext1 temp C:".Length;
                last = output.LastIndexOf("pack ext1 temp C:");
                str2 = output.Substring(first, last - first);

                str2 = str2.Replace("\r\n", "").Replace("\r", "").Replace("\n", "");
                str2 = str2.Replace(":", "");

                m_fuga_temp = double.Parse(str2, System.Globalization.CultureInfo.InvariantCulture);

                //pack temperature
                first = output.IndexOf("pack ext1 temp C:") + "pack ext1 temp C:".Length;
                //last = output.LastIndexOf("remaining energy mWh:");
                last = output.LastIndexOf("pack ext2 temp C:");
                str2 = output.Substring(first, last - first);

                str2 = str2.Replace("\r\n", "").Replace("\r", "").Replace("\n", "");
                str2 = str2.Replace(":", "");

                m_pack_temp = double.Parse(str2, System.Globalization.CultureInfo.InvariantCulture);

                //cell max voltage
                first = output.IndexOf("cell max mV:") + "cell max mV:".Length;
                last = output.LastIndexOf("cell max pos:");

                str2 = output.Substring(first, last - first);

                str2 = str2.Replace("\r\n", "").Replace("\r", "").Replace("\n", "");
                str2 = str2.Replace(":", "");

                m_CMax_volt = double.Parse(str2, System.Globalization.CultureInfo.InvariantCulture);

                //cell min voltage
                first = output.IndexOf("cell min mV:") + "cell min mV:".Length;
                last = output.LastIndexOf("cell min pos:");

                str2 = output.Substring(first, last - first);

                str2 = str2.Replace("\r\n", "").Replace("\r", "").Replace("\n", "");
                str2 = str2.Replace(":", "");

                m_CMin_volt = double.Parse(str2, System.Globalization.CultureInfo.InvariantCulture);

                //Status 1
                first = output.IndexOf("pack monitor status 1:") + "pack monitor status 1:".Length;
                last = output.LastIndexOf("pack monitor status 2:");
                str2 = output.Substring(first, last - first);
                System.Console.WriteLine("STATUS 1: " + str2);

                str2 = str2.Replace("\r\n", "").Replace("\r", "").Replace("\n", "");
                str2 = str2.Replace(":", "");
                str2 = str2.Replace(" ", "");
                System.Console.WriteLine("STATUS 1: " + str2);

                m_status1 = str2;
                System.Console.WriteLine("STATUS 1: " + m_status1);

                //Status 2
                first = output.IndexOf("pack monitor status 2:") + "pack monitor status 2:".Length;
                last = output.LastIndexOf("pack monitor status 3:");
                str2 = output.Substring(first, last - first);

                str2 = str2.Replace("\r\n", "").Replace("\r", "").Replace("\n", "");
                str2 = str2.Replace(":", "");
                str2 = str2.Replace(" ", "");

                m_status2 = str2;

                //Status 3
                first = output.IndexOf("pack monitor status 3:") + "pack monitor status 3:".Length;
                last = output.LastIndexOf("pack monitor status 4:");
                str2 = output.Substring(first, last - first);

                str2 = str2.Replace("\r\n", "").Replace("\r", "").Replace("\n", "");
                str2 = str2.Replace(":", "");
                str2 = str2.Replace(" ", "");

                m_status3 = str2;

                //Status 4
                first = output.IndexOf("pack monitor status 4:") + "pack monitor status 4:".Length;
                last = output.LastIndexOf("pack monitor fet ctrl:");
                str2 = output.Substring(first, last - first);

                str2 = str2.Replace("\r\n", "").Replace("\r", "").Replace("\n", "");
                str2 = str2.Replace(":", "");
                str2 = str2.Replace(" ", "");

                m_status4 = str2;

                //design capacity

                first = output.IndexOf("design capacity mAh:") + "design capacity mAh:".Length;
                last = output.LastIndexOf("full capacity mAh:");
                str2 = output.Substring(first, last - first);

                str2 = str2.Replace("\r\n", "").Replace("\r", "").Replace("\n", "");
                str2 = str2.Replace(":", "");
                str2 = str2.Replace(" ", "");

                m_design_capacity = double.Parse(str2, System.Globalization.CultureInfo.InvariantCulture);

                //full capacity

                first = output.IndexOf("full capacity mAh:") + "full capacity mAh:".Length;
                last = output.LastIndexOf("average mins to full:");
                str2 = output.Substring(first, last - first);

                str2 = str2.Replace("\r\n", "").Replace("\r", "").Replace("\n", "");
                str2 = str2.Replace(":", "");
                str2 = str2.Replace(" ", "");

                m_full_capacity = double.Parse(str2, System.Globalization.CultureInfo.InvariantCulture);

                //instantaneous current

                first = output.IndexOf("instantaneous current mA:") + "instantaneous current mA:".Length;
                last = output.LastIndexOf("average current mA:");
                str2 = output.Substring(first, last - first);

                str2 = str2.Replace("\r\n", "").Replace("\r", "").Replace("\n", "");
                str2 = str2.Replace(":", "");
                str2 = str2.Replace(" ", "");

                m_instant_current = double.Parse(str2, System.Globalization.CultureInfo.InvariantCulture);

                load_and_check_serial_number();

            }
            catch
            {
                return 0;
            }


            return 0;

        }

        public int load_and_check_serial_number()
        {
            string parameter_load = "";
            string[] parsed_output;
            string[] id_value_pairs;

            string prefix = TestMain.Self.get_partnum_prefix();
            string partnumber = TestMain.Self.get_partnum_number();
            string revision = TestMain.Self.get_partnum_revision();
            string serialnum = TestMain.Self.get_serial_number();
            string variant = TestMain.Self.get_partnum_variant();

            string prefix_read;
            string partnumber_read;
            string revision_read;
            string variant_read;
            string serialnum_read;
            //try
            //{
            //parameter_load = " -n sys --param_string=\"id_value_pairs = ({ id = 7; value = \\\""
            //        + prefix
            //        + "\\\"; }, { id = 8; value = "
            //        + partnumber
            //        + "; }, { id = 9; value = \\\""
            //        + revision
            //        + "\\\"; }, { id = 12; value = "
            //        + serialnum
            //        + "; }); worker_addresses = 10; param_block_id = 11;\"";
            //}
            //catch { }

            parameter_load = " -n sys --param_string=\"id_value_pairs = ({ id = 7; value = \\\""
                    + prefix
                    + "\\\"; }, { id = 8; value = "
                    + partnumber
                    + "; }, { id = 9; value = \\\""
                    + revision
                    + "\\\"; }, { id = 10; value = "
                    + variant
                    + "; }, { id = 12; value = "
                    + serialnum
                    + "; }); worker_addresses = 10; param_block_id = 11;\"";

            System.Console.WriteLine("PARAMETER_LOAD: " + parameter_load);

            //sys_cmd.RunCmd("C:\\Users\\tminniti\\Desktop\\HOB_CM_Test-Working\\can_protocol_inspect_5_1_1\\can_protocol_config.exe", 
            //    " -n sys --param_string=\"id_value_pairs = ({ id = 7; value = \\\"ASM\\\"; }, { id = 8; value = 1190; }, { id = 9; value = \\\"01\\\"; }, { id = 12; value = 006666; }); worker_addresses = 10; param_block_id = 11;");
            sys_cmd.RunCmd("C:\\OTE\\can_protocol_inspect_5_1_1\\can_protocol_config.exe", parameter_load);
            System.Console.WriteLine(sys_cmd.ms_cmd_output);

            
            sys_cmd.RunCmd("C:\\OTE\\can_protocol_inspect_5_1_1\\can_protocol_config.exe",
                " -n sys --param_string=\"worker_addresses = 10; param_block_id = 11; \"");
            //textBox1.Text = sys_cmd.ms_cmd_output;
            parsed_output = sys_cmd.ms_cmd_output.Split('\n');
            parsed_output = new ArraySegment<string>(parsed_output, 3, parsed_output.Length - 3).ToArray<string>();

            id_value_pairs = string.Join("", parsed_output).Split(',');

            prefix_read = id_value_pairs[7].Split(';')[5].Split('"')[1].Trim('\n', '\r', ' ');
            partnumber_read = id_value_pairs[8].Split(';')[3].Split('=')[1].Trim('\n', '\r', ' ');
            revision_read = id_value_pairs[9].Split(';')[5].Split('"')[1].Trim('\n', '\r', ' ');
            serialnum_read = id_value_pairs[12].Split(';')[3].Split('=')[1].Trim('\n', '\r', ' ');


            //System.Console.WriteLine(parsed_output[2,-1]);
            //config_output_data = JsonConvert.DeserializeObject(sys_cmd.ms_cmd_output);
            
            if (prefix == prefix_read && Int32.Parse(partnumber) == Int32.Parse(partnumber_read) && revision == revision_read && Int32.Parse(serialnum) == Int32.Parse(serialnum_read))
            {
                m_load_check_serialnum = "Success";
            }

            //m_load_check_serialnum =  prefix_read + " " + partnumber_read + " " + revision_read + " " + serialnum_read;


            return 0;
        }

    }
}
