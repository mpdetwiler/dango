﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using NationalInstruments.VisaNS;

namespace HOB_CM_Test
{
    class KeySi34461A : VisaDevice
    {
        ConfigData m_ConfigData = new ConfigData();
        string ms_stat_data;

        public KeySi34461A()
        {
            m_ConfigData.LoadConfigFile();

            SetVisaAddr(m_ConfigData.DMM_VISA_addr);
            //strVisaRsrc = "USB0::0x0957::0x1A07::MY53211377::0::INSTR";
        }

        public double Get_Meas_Volt()
        {
            SelectInstrument();
            Write_Data_Instrument("MEAS:VOLT:DC?");

            double d_data;
            try
            {
                d_data = double.Parse(Read_Instrument_Data(), System.Globalization.NumberStyles.Float);
            }
            catch (Exception exp)
            {
                MessageBox.Show(exp.Message);
                return -10000000.0;
            }
            return d_data;              // Read Data from the instrument
        }

        public void Sample_Count(int count)
        {
            SelectInstrument();
            string cmd = "SAMP:COUN " + count.ToString();
            Write_Data_Instrument(cmd);
        }

        public void Set_DC_NPLC(double d_plc)
        {
            SelectInstrument();
            string cmd = "VOLT:DC:NPLC " + d_plc.ToString();
            Write_Data_Instrument(cmd);
        }

        public void Config_DC_Range(int range)
        {
            SelectInstrument();
            string cmd = "CONF:VOLT:DC " + range.ToString() + ", " + "DEF";
            Write_Data_Instrument(cmd);
        }

        public void Turn_OnOff_Stat(int stat)
        {
            string cmd;
            SelectInstrument();
            if (stat == 0)
                cmd = "CALC:AVER:STAT OFF";
            else
                cmd = "CALC:AVER:STAT ON";
            Write_Data_Instrument(cmd);
        }

        public void Init_Stat()
        {
            SelectInstrument();
            Write_Data_Instrument("INIT");
        }

        public void WAIT()
        {
            SelectInstrument();
            Write_Data_Instrument("*WAI");
        }

        public string Get_Stat_Data()
        {
            SelectInstrument();
            Write_Data_Instrument("CALC:AVER:ALL?");
            ms_stat_data = Read_Instrument_Data();
            return ms_stat_data;
        }

        public double Get_Stat_Max()
        {
            if (ms_stat_data != null)
            {
                string[] data = ms_stat_data.Split(',');
                return StringToDouble(data[3]);
            }
            else
                return -100000000.0;
        }

        public double Get_Stat_Min()
        {
            if (ms_stat_data != null)
            {
                string[] data = ms_stat_data.Split(',');
                return StringToDouble(data[2]);
            }
            else
                return -100000000.0;                
        }

        //result based on 60Hz power 
        //return data is in ms
        public double Get_PLC_Time_Resolution(double plc)
        {
            if (plc == .02)
                return .3;
            else if (plc == .2)
                return 3.0;
            else if (plc == 1)
                return 16.7;
            else if (plc == 10)
                return .167;
            else if (plc == 100)
                return 1.67;
            else
            return 0;
        }
    }
}
