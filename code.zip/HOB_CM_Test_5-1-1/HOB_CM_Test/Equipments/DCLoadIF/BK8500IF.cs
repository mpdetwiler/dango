﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HOB_CM_Test
{
    class BK8500IF : DCLoadIF
    {
        BK8500 m_DCload;

        public BK8500IF()
        {
            m_DCload = new BK8500();
        }

        public override void GetCOMPortList(ref string strCOM)
        {
            m_DCload.GetCOMPortList(ref strCOM);
        }

        public override void get_voltage_curr_data()
        {
            m_DCload.get_voltage_curr_data();
            m_DC_Curr_val = m_DCload.m_DC_Curr_val;
            m_DC_Voltage_val = m_DCload.m_DC_Voltage_val;
        }

        public override void load_on()
        {
            //m_McDaqIF.SetLoadConnection(1);
            //System.Threading.Thread.Sleep(100);
            m_DCload.load_on();
        }

        public override void load_off()
        {
            //m_McDaqIF.SetLoadConnection(0);
            m_DCload.load_off();

        }

        public override void load_mode(byte mode)
        {
            m_DCload.load_mode(mode);
        }

        public override void Set_function_mode(byte mode)
        {
            m_DCload.Set_function_mode(mode);
        }

        public override void set_current(int current)
        {
            m_DCload.set_current(current);
        }

        public override void set_Rload(int Rload)
        {
            m_DCload.set_Rload(Rload);
        }

        public override void set_trans_load(int load_on_time1, int load_on_time2, int load_current1, int load_current2)
        {
            m_DCload.set_trans_load(load_on_time1, load_on_time2, load_current1, load_current2);
        }
    }
}
