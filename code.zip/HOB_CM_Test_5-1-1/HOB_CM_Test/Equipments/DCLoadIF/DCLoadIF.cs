﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HOB_CM_Test
{
    class DCLoadIF
    {
        public McDaqIF m_McDaqIF;

        public double m_DC_Curr_val, m_DC_Voltage_val;

        public virtual void GetCOMPortList(ref string strCOM) { }
        public virtual void get_voltage_curr_data()
        {
            m_DC_Curr_val = 0;
            m_DC_Voltage_val = 0;
        }
        public virtual void load_on() { }
        public virtual void load_off() { }
        /*
         0 is CC
         1 is CV
         2 is CW
         3 is CR*/
        public virtual void load_mode(byte mode) { }
        public virtual void Set_function_mode(byte mode) { }
        public virtual void set_current(int current) { }
        public virtual void set_Rload(int Rload) { }
        public virtual void set_trans_load(int load_on_time1, int load_on_time2, int load_current1, int load_current2) { }

        public virtual void SetMcDaqIF(McDaqIF daq)
        {
            m_McDaqIF = daq;
        }

    }
}
