﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TotalPhase;

namespace HOB_CM_Test
{
    class CAN_init
    {
        private static int m_komodo_km;
        private static int can_ready;
        int m_Komodo_km;
        int port = 0;               //Use port 0

        public int M_Komodo_km      //CAN Handle
        {
            get { return m_komodo_km; }
            set { m_komodo_km = value; }
        }

        public int Can_Ready        //CAN is ready for TX and RX
        {
            get { return can_ready; }
            set { can_ready = value; }
        }

        public int CAN_close()      //close CAN Handle
        {
            if (KomodoApi.km_close(port) != 0)
                return -1;
            return 0;
        }
    
        public int InitCAN()        //Initailize and open CAN
        {
            int i;
            int ret;
            km_power_t power;
            int port = 0;               //Use port 0
            ushort timeout = 200;       //ms
                                        //uint        bitrate = 12500; //Hz
            uint bitrate = 1000000;     //Hz

            power = km_power_t.KM_TARGET_POWER_ON;

            // Open the interface
            m_Komodo_km = KomodoApi.km_open(port);
            M_Komodo_km = m_Komodo_km;

            ret = KomodoApi.km_acquire(m_Komodo_km, KomodoApi.KM_FEATURE_CAN_A_CONFIG |
                                        KomodoApi.KM_FEATURE_CAN_A_LISTEN |
                                        KomodoApi.KM_FEATURE_CAN_A_CONTROL |
                                        KomodoApi.KM_FEATURE_GPIO_CONFIG |
                                        KomodoApi.KM_FEATURE_GPIO_LISTEN);
            Console.Write("Acquired features 0x{0:x}\n", ret);

            // Set bitrate
            ret = KomodoApi.km_can_bitrate(m_Komodo_km, km_can_ch_t.KM_CAN_CH_A, bitrate);
            Console.Write("Bitrate set to {0:d} kHz\n", ret / 1000);

            // Set timeout
            KomodoApi.km_timeout(m_Komodo_km, timeout);
            Console.Write("Timeout set to {0:d} ms\n", timeout);

            // Set target power
            KomodoApi.km_can_target_power(m_Komodo_km, km_can_ch_t.KM_CAN_CH_A, power);
            Console.Write("Target power {0:d}\n",
                   power == km_power_t.KM_TARGET_POWER_ON ? "ON" : "OFF");

            int NUM_GPIOS = 8;
            // Configure all GPIO pins as inputs
            for (i = 0; i < NUM_GPIOS; i++)
                KomodoApi.km_gpio_config_in(m_Komodo_km, (byte)i,
                                  (byte)km_pin_bias_t.KM_PIN_BIAS_PULLUP,
                                  (byte)km_pin_trigger_t.KM_PIN_TRIGGER_BOTH_EDGES);
            Console.Write("All pins set as inputs\n");

            ret = KomodoApi.km_enable(m_Komodo_km);
            if (ret != (int)km_status_t.KM_OK)
            {
                Console.Write("Unable to enable Komodo\n");
                //m_CANInit = 0;
                //MessageBox.Show("Unable to initialize Komodo module.");
                return -1;
            }

            //m_CANInit = 1;
            return 0;
        }
    }
}
