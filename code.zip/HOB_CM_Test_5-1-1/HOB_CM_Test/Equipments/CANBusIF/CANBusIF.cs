﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TotalPhase;

namespace HOB_CM_Test
{
    class CANBusIF
    {
        
        CAN_message can_message = new CAN_message();

        public virtual byte[] CAN_rx()
        {
            return can_message.CAN_rx();
        }

        public virtual int CAN_tx(ref byte[] buffer, uint msg_id)
        {
            return can_message.CAN_tx(ref  buffer, msg_id);
        }

        public virtual void CAN_Messages(byte item, byte command)
        {
            can_message.CAN_Messages(item, command);
        }
    }
}
