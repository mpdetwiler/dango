﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TotalPhase;
using System.Windows.Forms;

namespace HOB_CM_Test
{
    class CAN_message
    {
        CAN_init can_init;
        byte m_data_size = 8;
        //uint m_msg_id_mask = 0x10005100;
        uint m_msg_id_mask = 0x000;

        public CAN_message()
        {
            can_init = new CAN_init();
            try
            {
                int val = can_init.InitCAN();
                if (val < 0)
                    throw new Exception();
            }
            catch(Exception e)
            {
                MessageBox.Show("CAN Bus init failed. " + e);
            }
        }

        public byte[] CAN_rx()                            //should be configured as callback
        {

            int ret;
            byte[] rx_data = new byte[m_data_size];
            try
            {
                KomodoApi.km_can_info_t CAN_packet_info = new KomodoApi.km_can_info_t();
                KomodoApi.km_can_packet_t CAN_packet_data = new KomodoApi.km_can_packet_t();
                CAN_packet_info.bitrate_hz = 1000000;
                CAN_packet_info.channel = km_can_ch_t.KM_CAN_CH_A;

                for (int cnt = 0; cnt < 5; cnt++)
                {
                    Console.WriteLine("loop: " + cnt.ToString());
                    ret = KomodoApi.km_can_read(can_init.M_Komodo_km, ref CAN_packet_info, ref CAN_packet_data, m_data_size, rx_data);
                    if (ret < 0)
                    {
                        Console.Write("error={0:d}", ret);
                        return rx_data;
                    }
                    if (CAN_packet_info.events == 0)
                        break;
                }
                if ((CAN_packet_info.status == (int)km_status_t.KM_OK) && (CAN_packet_info.events == 0))
                {
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Error in CAN Rx: " + e.Message);
            }
            return rx_data;
        }

        public int CAN_tx(ref byte[] buffer, uint msg_id)
        {

            uint arb_count = 0;

            KomodoApi.km_can_packet_t pkt;
            //pkt.extend_addr = 1;
            try
            {
                pkt.extend_addr = 0;
                pkt.dlc = m_data_size;
                pkt.remote_req = 0;
                pkt.id = m_msg_id_mask | msg_id;  //| (slotID << 4);
                                                  //pkt.id = msg_id;
                KomodoApi.km_can_write(can_init.M_Komodo_km, km_can_ch_t.KM_CAN_CH_A, 0, pkt, m_data_size, buffer, ref arb_count);
            }
            catch(Exception e)
            {
                Console.WriteLine("Error: " + e.Message);
                return -1;
            }
            return 0;
        }
        /*Item
         * 1 I2C Pack Voltage
         * 2 I2C Cell Voltage
         * 3 LED
         * 4 Button
         * 5 Address_in
         * 6 Pack Current
         * 7 I2C Temperature
         * 8 CFET
         * 9 DFET
         * A CDFET
         * B PWM
         * C CAN
         * D I2C
         * E Presence in
         * F In FETOFF
         * 10 In INT
         * 11 In EOC
         * 12 In SD
         * 13 I2C Enable
         * 14 AD PACK Voltage
         * 
         * Command
         * 1 - ON
         * 0 - OFF
         */
        public void CAN_Messages(byte item, byte command)
        {
            byte[] data = new byte[8];
            for (int i = 0; i < 8; i++)
                data[i] = 0x00;
            data[0] = item;
            data[1] = command;

            if(CAN_tx(ref data, 801) != 0)
            {
                Console.WriteLine("Error in CAN transmit.");
            }
        }
    }
}
