﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HOB_CM_Test
{
    class BK9122APS : SerComApp
    {
        ConfigData m_configData;
        int m_BKopen;
        double m_dmax_curr = 2.5;

        public BK9122APS()
        {
            m_BKopen = 0;
            m_configData = new ConfigData();

            m_configData.LoadConfigFile();

            if (OpenPort(m_configData.BK_PS_comport) == -1)
                return;
        }

        public void Supply_Remote()
        {
            string cmd = "syst:rem";
            Write(cmd);
            System.Threading.Thread.Sleep(1000);
        }

        public int IsOpen()
        {
            return m_BKopen;
        }

        public void Supply_Range_High()
        {

        }

        public string GetInstrumentID()
        {
            string cmd = "*IDN?";
            Write(cmd);
            General_Delay();
            ReadRxBufferUntilNewline();

            string temp = new string(m_char_buffer_final);
            string[] num = temp.Split('\n');
            return num[0];
        }

        public void Supply_Output_ON()
        {
            string cmd = ":OUTP:STAT ON";
            Write(cmd);
            General_Delay();
        }

        public void Supply_Output_OFF()
        {
            string cmd = ":OUTP:STAT OFF";
            Write(cmd);
            General_Delay();
        }

        public double Meas_Supply_Voltage()
        {
            string cmd = ":MEAS:VOLT:DC?";
            Write(cmd);
            General_Delay();
            ReadRxBufferUntilNewline();

            char sep = '\n';
            string temp = new string(m_char_buffer_final);
            string[] num = temp.Split(sep);
            return StringToDouble(num[0]);

        }

        public double Meas_Supply_Current()
        {
            string cmd = ":MEAS:CURR:DC?";
            Write(cmd);
            General_Delay();
            ReadRxBufferUntilNewline();

            char sep = '\n';
            string temp = new string(m_char_buffer_final);
            string[] num = temp.Split(sep);
            return StringToDouble(num[0]);
        }

        public void Supply_Out_Volt(string volt)
        {
            string cmd = "SOUR:VOLT:LEV:IMM:AMPL " + volt;
            Write(cmd);
            General_Delay();
        }

        public void Supply_Out_Current(string current)
        {
            if (StringToDouble(current) >= m_dmax_curr)
            {
                MessageBox.Show(current + " is more than equipment current limit.  Will set to" + m_dmax_curr.ToString());
                current = m_dmax_curr.ToString();
            }
            string cmd = "SOUR:CURR:LEV:IMM:AMPL " + current;
            Write(cmd);
            General_Delay();
        }

        private void General_Delay()
        {
            System.Threading.Thread.Sleep(150);
        }
    }
}
