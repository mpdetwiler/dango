﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HOB_CM_Test
{
    class BK9201PS : VisaDevice
    {
        ConfigData m_ConfigData = new ConfigData();
        double m_dmax_curr = 10;
        public BK9201PS()
        {
            m_ConfigData.LoadConfigFile(); 
            SetVisaAddr(m_ConfigData.PSBK_VISA_addr);
        }


        public void Supply_Remote()
        {
            string cmd = "syst:rem";
            SelectInstrument();
            Write_Data_Instrument(cmd);
            General_Delay();
        }
/*
        public string GetInstrumentID()
        {
            string cmd = "*IDN?";
            SelectInstrument();
            Write_Data_Instrument(cmd);
            General_Delay();
            string readback = Read_Instrument_Data();
            readback = readback.Replace("A\n", string.Empty);
            return readback;
        }
*/
        public void Supply_Output_ON()
        {
            string cmd = ":OUTP:STAT ON";
            SelectInstrument();
            Write_Data_Instrument(cmd);
            General_Delay();
        }

        public void Supply_Output_OFF()
        {
            string cmd = ":OUTP:STAT OFF";
            SelectInstrument();
            Write_Data_Instrument(cmd);
            General_Delay();
        }

        public double Meas_Supply_Voltage()
        {
            SelectInstrument();
            Write_Data_Instrument("MEAS:VOLT:DC?");
            string readback = Read_Instrument_Data();
            readback = readback.Replace("A\n", string.Empty);
            return double.Parse(readback);
        }

        public double Meas_Supply_Current()
        {
            SelectInstrument();
            Write_Data_Instrument("MEAS:CURR:DC?");
            string readback = Read_Instrument_Data();
            readback = readback.Replace("A\n", string.Empty);
            return double.Parse(readback);
        }

        public void Supply_Out_Volt(string volt)
        {
            SelectInstrument();
            string cmd = "SOUR:VOLT:LEV:IMM:AMPL " + volt;
            Write_Data_Instrument(cmd);
            General_Delay();
        }

        public void Supply_Out_Current(string current)
        {
            if (StringToDouble(current) >= m_dmax_curr)
            {
                MessageBox.Show(current + " is more than equipment current limit.  Will set to" + m_dmax_curr.ToString());
                current = m_dmax_curr.ToString();
            }
            SelectInstrument();
            string cmd = "SOUR:CURR:LEV:IMM:AMPL " + current;
            Write_Data_Instrument(cmd);
            General_Delay();
        }

        private void General_Delay()
        {
            System.Threading.Thread.Sleep(150);
        }
    }
}
