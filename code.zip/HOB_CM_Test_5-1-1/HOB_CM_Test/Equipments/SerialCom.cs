﻿using System;
using System.Threading;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.IO.Ports;
using System.Windows.Forms;

namespace HOB_CM_Test
{
    class SerialCom : Conversion 
    {
        int RX_THRESHOLD = 100;
        
        public SerialPort serialport;
        string BK_comport = "";

        static private Object thisLock = new Object();
        public char[] m_char_buffer_temp = new char[128];
        public char[] m_char_buffer_final = new char[128];
        public byte[] m_byte_buffer_temp = new byte[128];
        public byte[] m_byte_buffer_final = new byte[128];

        public SerialCom()
        {
            serialport = new SerialPort();
            serialport.ReadTimeout = 500;
            serialport.WriteTimeout = 500;
            serialport.ReadBufferSize = 256;
            serialport.BaudRate = 9600;       //make sure instrument also has same baud rate setting
            serialport.ReceivedBytesThreshold = RX_THRESHOLD;

            serialport.DtrEnable = true;
        }

        public void SetBaudRate(int rate)
        {
            serialport.BaudRate = rate;
        }

        public int OpenPort(string port)
        {
            try
            {
                if (!serialport.IsOpen)
                {
                    serialport.PortName = port;
                    serialport.Open();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unable to open com port.  " + ex.Message);
                return -1;
            }
            return 0;
        }

        public void SetPort(string port)
        {
            BK_comport = port;
        }

        public void Write(byte[] buffer, int offset, int count)
        {
            lock (thisLock)
            {
                serialport.DiscardInBuffer();
                System.Threading.Thread.Sleep(10);
                serialport.Write(buffer, offset, count);
            }
        }

        public void Write(char[] buffer, int offset, int count)
        {
            lock (thisLock)
            {
                serialport.DiscardInBuffer();
                System.Threading.Thread.Sleep(10);
                serialport.Write(buffer, offset, count);
            }
        }

        public void Write(string buffer)
        {
            lock (thisLock)
            {
                serialport.DiscardInBuffer();
                System.Threading.Thread.Sleep(10);
                serialport.WriteLine(buffer);
            }
        }

        public void GetCOMPortList(ref string strCOM)
        {
            strCOM = "";
            foreach (string item in System.IO.Ports.SerialPort.GetPortNames())
            {
                //Store Names in string
                strCOM += item + "; ";
            }
        }

        public int IsPortOpen()
        {
            if (serialport.IsOpen)
                return 1;
            else
                return 0;
        }

        public void ClosePort()
        {
            serialport.Close();
        }
    }
}
