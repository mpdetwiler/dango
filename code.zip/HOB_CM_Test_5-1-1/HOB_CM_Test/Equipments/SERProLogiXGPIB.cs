﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HOB_CM_Test
{
    class SERProLogiXGPIB : SerComApp
    {
        string m_GPIB_addr;
        public SERProLogiXGPIB()
        {
            SetBaudRate(115200);
        }
        
        public void SetGPIBAddress(byte address)
        {
            string addr = ByteToString(address);
            m_GPIB_addr = "++addr " + addr + "\n";
        }

        public void WriteData(string buffer)
        {
            //Select GPIB address
            Write(m_GPIB_addr);
            //write buffer
            Write( (buffer + "\n") );
        }


    }
}
