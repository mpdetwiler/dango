﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;


namespace HOB_CM_Test
{
    class KeySiE3633A : SerComApp
    {
        ConfigData m_configData;
 

        int m_BKopen;
        double m_dmax_curr = 10.0;
        double md_volt_low = 8.0;
//        static int m_curr_range;

        public KeySiE3633A()
        {
            m_BKopen = 0;
            m_configData = new ConfigData();
    

            m_configData.LoadConfigFile();

            if (OpenPort(m_configData.BK_PS_comport) == -1)
                return;

            Supply_Remote();

        }

        public void Supply_Remote()
        {
            string cmd = "syst:rem";
            Write(cmd);
            System.Threading.Thread.Sleep(1000);
        }

        public int IsOpen()
        {
            return m_BKopen;
        }

        public void Supply_Range_High()
        {
            Write("VOLT:RANG?");
            System.Threading.Thread.Sleep(50);
            ReadRxBufferUntilNewline();
            if (m_char_buffer_final[1] == '8')
                return;

            string cmd = "VOLT:RANG P8V";
            Write(cmd);
            System.Threading.Thread.Sleep(1000);
        }

        public void Supply_Range_Low()
        {
            Write("VOLT:RANG?");
            System.Threading.Thread.Sleep(50);
            ReadRxBufferUntilNewline();
            if (m_char_buffer_final[1] == '2')
                return;

            string cmd = "VOLT:RANG P20V";
            Write(cmd);
            System.Threading.Thread.Sleep(1000);
        }

        public string GetInstrumentID()
        {
            string cmd = "*IDN?";
            Write(cmd);
            General_Delay();
            ReadRxBufferUntilNewline();

            string temp = new string(m_char_buffer_final);
            string[] num = temp.Split('\n');
            return num[0];
        }

        public void Supply_Output_ON()
        {
            string cmd = ":OUTP ON";
            Write(cmd);
            General_Delay();
        }

        public void Supply_Output_OFF()
        {
            string cmd = ":OUTP OFF";
            Write(cmd);
            General_Delay();           
        }

        public double Meas_Supply_Voltage()
        {
            string cmd = ":MEAS:VOLT?";
            Write(cmd);
            General_Delay();
            ReadRxBufferUntilNewline();

            char sep = '\n';
            string temp = new string(m_char_buffer_final);
            string[] num = temp.Split(sep);
            return StringToDouble(num[0]);

        }

        public double Meas_Supply_Current()
        {
            string cmd = ":MEAS:CURR?";
            Write(cmd);
            General_Delay();
            ReadRxBufferUntilNewline();

            char sep = '\n';
            string temp = new string(m_char_buffer_final);
            string[] num = temp.Split(sep);
            return StringToDouble(num[0]);
        }

        public void Supply_Out_Volt(string volt)
        {
            if (StringToDouble(volt) > md_volt_low)
                Supply_Range_Low();
            else
                Supply_Range_High();

            string cmd = "SOUR:VOLT:LEV:IMM:AMPL " + volt;
            Write(cmd);
            General_Delay();
        }

        public void Supply_Out_Current(string current)
        {
            if (StringToDouble(current) >= m_dmax_curr)
            {
                MessageBox.Show(current + " is more than equipment current limit.  Will set to" + m_dmax_curr.ToString());
                current = m_dmax_curr.ToString();
            }
            string cmd = "SOUR:CURR:LEV:IMM:AMPL " + current;
            Write(cmd);
            General_Delay();
        }

        private void General_Delay()
        {
            System.Threading.Thread.Sleep(150);
        }
    }
}
