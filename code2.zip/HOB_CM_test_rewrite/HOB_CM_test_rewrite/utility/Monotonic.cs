﻿using System;
using System.Diagnostics;
using System.Threading;

namespace HOB_CM_test_rewrite.utility
{
    public static class
    Monotonic
    {
        public static long
        currentTick()
        {
            lock(sLock)
            {
                var result = (sCurrentTick += sTimer.ElapsedMilliseconds);

                sTimer.Restart();

                return result;
            }
        }

        private static void
        loop()
        {
            do
            {
                currentTick();

                Thread.Sleep(10_000);
            }
            while(true);
        }

        private static readonly Object sLock = new Object();
        private static readonly Stopwatch sTimer = new Stopwatch();
        private static readonly Thread sPeriodicCaller = new Thread(new ThreadStart(loop));
        private static long sCurrentTick = 0L;

        static
        Monotonic()
        {
            sTimer.Start();
            sPeriodicCaller.IsBackground = true;
            sPeriodicCaller.Start();
        }
    }
}
