﻿using System;

namespace HOB_CM_test_rewrite.agents
{
    public interface
    IScheduler
    {
        bool
        processMessages();

        void
        waitMessages();

        void
        timedWaitMessages
        (in long deadline);

        long
        currentTick();
    }

    internal struct
    Scheduler<A>:IScheduler
    where A:AgentBase<A>
    {
        public
        Scheduler
        (in MessageManager<A> manager, in A agent)
        {
            mManager = manager;
            mAgent = agent;
        }

        bool
        IScheduler.processMessages()
        {
            return mManager.processMessages(mAgent);
        }

        void
        IScheduler.waitMessages()
        {
            mManager.waitMessages();
        }

        void
        IScheduler.timedWaitMessages
        (in long deadline)
        {
            mManager.timedWaitMessages(deadline);
        }

        long
        IScheduler.currentTick()
        {
            return utility.Monotonic.currentTick();
        }

        private readonly MessageManager<A> mManager;
        private readonly A mAgent;
    }
}
