﻿using System;

namespace utility
{
    public static class
    Conversion
    {
        public static string
        byteToString(in byte val)
        {
            return val.ToString();
        }

        public static string
        byteToStringHex(in byte val)
        {
            return "0x" + val.ToString("X2");
        }

        public static int
        hexStringToInt(in string str)
        {
            return int.Parse(str, System.Globalization.NumberStyles.HexNumber);
        }

        public static double
        stringToDouble(in string str)
        {
            return double.Parse(str, System.Globalization.CultureInfo.InvariantCulture);
        }
    }
}
