using System;

namespace agents
{
    public sealed class
    ExampleAgent:AgentExtern<ExampleAgentIntern>
    {
        public
        ExampleAgent
        (in string name):
        base(construct, name)
        {

        }

        public void
        msgPrintHello
        (string str)
        {
            sendMessage
            (
                (ExampleAgentIntern agent) =>
                {
                    agent.printHello(str);
                }
            );
        }

        private static ExampleAgentIntern
        construct
        (AgentExtern<ExampleAgentIntern> owner, string name)
        {
            return new ExampleAgentIntern(owner, name);
        }
    }


    public sealed class
    ExampleAgentIntern:AgentIntern<ExampleAgentIntern>
    {
        public
        ExampleAgentIntern
        (in AgentExtern<ExampleAgentIntern> owner, in string name):
        base(owner, name)
        {

        }

        public void
        printHello
        (in string str)
        {
            Console.WriteLine("Hello, " + str + "! My name is " + name() + "!");
        }
    }
}