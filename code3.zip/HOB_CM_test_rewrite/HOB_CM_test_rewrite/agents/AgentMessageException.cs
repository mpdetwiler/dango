﻿using System;

namespace agents
{
    public class
    AgentMessageException:Exception
    {
        public
        AgentMessageException
        (in string receiverName):
        base("AgentMessageException: Attempted to send message to dead Agent \"" + receiverName + "\"")
        {

        }
    }
}
