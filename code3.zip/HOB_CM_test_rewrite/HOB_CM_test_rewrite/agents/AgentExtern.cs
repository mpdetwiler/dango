﻿using System;
using System.Threading;
using System.Diagnostics;

namespace agents
{
    public abstract class
    AgentExtern<A>
    where A:AgentIntern<A>
    {
        protected
        AgentExtern
        (in Func<AgentExtern<A>, string, A> constructor, in string name)
        {
            mThread = new AgentThread<A>(constructor, this, name);
        }

        ~AgentExtern()
        {
            mThread.kill();
        }

        protected bool
        trySendMessage
        (in Action<A> func)
        {
            return mThread.trySendMessage(func);
        }

        protected void
        sendMessage
        (in Action<A> func)
        {
            mThread.sendMessage(func);
        }

        private readonly AgentThread<A> mThread;
    }

    internal sealed class
    AgentThread<A>
    where A:AgentIntern<A>
    {
        public
        AgentThread
        (in Func<AgentExtern<A>, string, A> constructor, in AgentExtern<A> owner, in string name)
        {
            mName = name;

            var starter = new AgentThreadStarter<A>(constructor, owner, name);

            starter.start(out mThread, out mManager);
        }

        public bool
        trySendMessage
        (in Action<A> func)
        {
            return mManager.tryNewMessage(func);
        }

        public void
        sendMessage
        (in Action<A> func)
        {
            mManager.newMessage(func, mName);
        }

        public void
        kill()
        {
            mManager.kill();
        }

        public string
        name()
        {
            return mName;
        }

        private readonly string mName;
        private readonly Thread mThread;
        private readonly MessageManager<A> mManager;
    }

    internal sealed class
    AgentThreadStarter<A>
    where A:AgentIntern<A>
    {
        public
        AgentThreadStarter
        (in Func<AgentExtern<A>, string, A> constructor, in AgentExtern<A> owner, in string name)
        {
            mConstructor = constructor;
            mOwner = owner;
            mName = name;
            mManager = null;
            mExcept = null;
        }

        public void
        start
        (out Thread thread, out MessageManager<A> manager)
        {
            thread = new Thread(new ThreadStart(threadFunc));

            thread.IsBackground = true;

            thread.Start();

            lock(this)
            {
                while(mConstructor != null)
                {
                    Monitor.Wait(this);
                }
            }

            Debug.Assert(mConstructor == null);
            Debug.Assert(mOwner == null);
            Debug.Assert(mName == null);
            Debug.Assert((mManager != null) ^ (mExcept != null));

            if(mExcept != null)
            {
                var except = mExcept;

                mExcept = null;

                throw except;
            }

            manager = mManager;

            mManager = null;
        }

        private void
        threadFunc()
        {
            A agent = constructAgent();

            if(agent == null)
            {
                return;
            }

            var manager = new MessageManager<A>();

            lock(this)
            {
                mConstructor = null;

                mManager = manager;

                Monitor.Pulse(this);
            }

            agent.run(new Scheduler<A>(manager, agent));
        }

        private A
        constructAgent()
        {
            Func<AgentExtern<A>, string, A> constructor;
            AgentExtern<A> owner;
            string name;

            lock(this)
            {
                constructor = mConstructor;
                owner = mOwner;
                name = mName;
                mOwner = null;
                mName = null;
            }

            A agent;

            try
            {
                agent = constructor.Invoke(owner, name);
            }
            catch(Exception except)
            {
                lock(this)
                {
                    mConstructor = null;

                    mExcept = except;

                    Monitor.Pulse(this);
                }

                return null;
            }

            return agent;
        }

        private Func<AgentExtern<A>, string, A> mConstructor;
        private AgentExtern<A> mOwner;
        private string mName;
        private MessageManager<A> mManager;
        private Exception mExcept;
    }

    internal sealed class
    Message<A>
    where A : AgentIntern<A>
    {
        public
        Message(in Action<A> func)
        {
            mFunc = func;
            next = null;
        }

        public Message<A>
        appendTo(in Message<A> tail)
        {
            return (tail.next = this);
        }

        public void
        apply(in A agent)
        {
            mFunc.Invoke(agent);
        }

        public Message<A> next { get; private set; }
        private readonly Action<A> mFunc;
    }

    internal sealed class
    MessageManager<A>
    where A:AgentIntern<A>
    {
        public
        MessageManager()
        {
            mAlive = true;
            mWaiting = false;
            mHead = null;
            mTail = null;
        }

        public void
        kill()
        {
            lock(this)
            {
                if(mAlive)
                {
                    mAlive = false;

                    if(mWaiting)
                    {
                        Monitor.Pulse(this);
                    }
                }
            }
        }

        public bool
        processMessages
        (in A agent)
        {
            bool alive;
            Message<A> current;

            lock(this)
            {
                alive = mAlive;

                current = mHead;

                if(current == null)
                {
                    return alive;
                }

                mHead = mTail = null;
            }

            do
            {
                try
                {
                    current.apply(agent);
                }
                catch(AgentMessageException except)
                {
                    Console.WriteLine("Agent \"" + agent.name() + "\": Failed to send message:\n" + except.Message);
                }
                catch(Exception except)
                {
                    Console.WriteLine("Agent \"" + agent.name() + "\": Execption thrown during message processing:\n" + except.Message);

                    return false;
                }

                current = current.next;
            }
            while(current != null);

            return alive;
        }

        public void
        waitMessages()
        {
            lock(this)
            {
                while(mAlive && mHead == null)
                {
                    mWaiting = true;

                    Monitor.Wait(this);

                    mWaiting = false;
                }
            }
        }

        public void
        timedWaitMessages
        (in long deadline)
        {
            lock(this)
            {
                while(mAlive && mHead == null)
                {
                    var current = utility.Monotonic.currentTick();

                    if(current >= deadline)
                    {
                        break;
                    }

                    var timeout = (int)Math.Min((long)int.MaxValue, deadline - current);

                    mWaiting = true;

                    Monitor.Wait(this, timeout);

                    mWaiting = false;
                }
            }
        }

        public bool
        tryNewMessage
        (in Action<A> func)
        {
            var m = new Message<A>(func);

            lock(this)
            {
                if(!mAlive)
                {
                    return false;
                }

                if(mHead == null)
                {
                    mHead = mTail = m;
                }
                else
                {
                    mTail = m.appendTo(mTail);
                }

                if(mWaiting)
                {
                    Monitor.Pulse(this);
                }
            }

            return true;
        }

        public void
        newMessage
        (in Action<A> func, in string agentName)
        {
            if(!tryNewMessage(func))
            {
                throw new AgentMessageException(agentName);
            }
        }

        private bool mAlive;
        private bool mWaiting;
        private Message<A> mHead;
        private Message<A> mTail;
    }
}
