﻿using System;

namespace agents
{
    public abstract class
    AgentIntern<A>
    where A:AgentIntern<A>
    {
        protected
        AgentIntern
        (in AgentExtern<A> owner, in string name)
        {
            mOwner = new WeakReference<AgentExtern<A>>(owner);
            mName = name;
        }

        protected AgentExtern<A>
        owner()
        {
            if (mOwner.TryGetTarget(out var result))
            {
                return result;
            }

            return null;
        }

        public string
        name()
        {
            return mName;
        }

        internal virtual void
        run
        (in IScheduler scheduler)
        {
            do
            {
                scheduler.waitMessages();
            }
            while(scheduler.processMessages());
        }

        private readonly WeakReference<AgentExtern<A>> mOwner;
        private readonly string mName;
    }
}
